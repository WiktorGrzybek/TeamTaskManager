﻿// Services/Interfaces/ITaskService.cs
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TeamTaskManager.Models;

namespace TeamTaskManager.Services.Interfaces
{
    public interface ITaskService
    {
        Task<List<TaskItem>> GetAllAsync();
        Task<TaskItem> GetByIdAsync(int taskId);
        Task<TaskItem> CreateTaskAsync(TaskItem task, List<int> assignedUserIds);
        Task UpdateTaskAsync(TaskItem task, List<int> assignedUserIds);
        Task DeleteTaskAsync(int taskId);
        Task AddProgressAsync(int taskId, Progress progress);
        Task<List<Progress>> GetProgressHistoryAsync(int taskId);
        Task<List<TaskItem>> FilterTasksAsync(int? teamId, int? userId, DateTime? dueBefore, string status);
    }
}
