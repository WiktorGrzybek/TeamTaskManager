﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TeamTaskManager.Models;

namespace TeamTaskManager.Services.Interfaces
{
    public interface IUserService
    {
        Task<bool> IsEmailAvailableAsync(string email);
        Task<User> AuthenticateAsync(string email, string password);
        Task<User> CreateUserAsync(User newUser, string rawPassword);
        Task<User> GetByIdAsync(int userId);
        Task<List<User>> GetAllAsync();
        Task UpdateUserAsync(User user);
        Task DeleteUserAsync(int userId);
    }
}
