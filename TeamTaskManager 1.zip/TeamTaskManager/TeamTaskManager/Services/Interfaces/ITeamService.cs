﻿// Services/Interfaces/ITeamService.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using TeamTaskManager.Models;

namespace TeamTaskManager.Services.Interfaces
{
    public interface ITeamService
    {
        // Pobierz listę wszystkich zespołów
        Task<List<Team>> GetAllAsync();

        // Pobierz pojedynczy zespół po jego ID (łącznie z członkami)
        Task<Team> GetByIdAsync(int teamId);

        // Utwórz nowy zespół
        Task<Team> CreateTeamAsync(Team team);

        // Zaktualizuj dane istniejącego zespołu (np. nazwa, opis)
        Task UpdateTeamAsync(Team team);

        // Usuń zespół (oraz wszystkie powiązane encje: członkowie, przypisania zadań itp.)
        Task DeleteTeamAsync(int teamId);

        // Zapisz listę członków w danym zespole:
        // – usuwa dotychczasowych członków i dodaje nowych wg przekazanego userIds
        Task UpdateTeamMembersAsync(int teamId, List<int> userIds);
    }
}
