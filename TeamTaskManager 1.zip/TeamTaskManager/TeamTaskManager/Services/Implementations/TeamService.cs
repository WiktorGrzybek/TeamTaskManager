﻿// File: Services/Implementations/TeamService.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TeamTaskManager.Data;
using TeamTaskManager.Models;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Services.Implementations
{
    public class TeamService : ITeamService
    {
        private readonly AppDbContext _context;

        public TeamService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Team>> GetAllAsync()
        {
            // Pobiera wszystkie zespoły wraz z członkami, twórcą i zadaniami
            return await _context.Teams.AsNoTracking()
                .Include(t => t.TeamMembers)
                    .ThenInclude(tm => tm.User)
                .Include(t => t.CreatedByUser)
                .Include(t => t.TaskItems)
                .AsNoTracking()
                .OrderBy(t => t.Name)
                .ToListAsync();
        }

        public async Task<Team> GetByIdAsync(int teamId)
        {
            var team = await _context.Teams.AsNoTracking()
                .Include(t => t.TeamMembers)
                    .ThenInclude(tm => tm.User)
                .Include(t => t.CreatedByUser)
                .Include(t => t.TaskItems)
                .SingleOrDefaultAsync(t => t.Id == teamId);

            if (team == null)
                throw new KeyNotFoundException("Nie znaleziono zespołu.");

            return team;
        }

        public async Task<Team> CreateTeamAsync(Team team)
        {
            _context.Teams.Add(team);
            await _context.SaveChangesAsync();
            return team;
        }

        public async Task UpdateTeamAsync(Team team)
        {
            var existing = await _context.Teams.FindAsync(team.Id);
            if (existing == null)
                throw new KeyNotFoundException("Nie znaleziono zespołu.");

            existing.Name = team.Name;
            existing.Description = team.Description;
            _context.Teams.Update(existing);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTeamAsync(int teamId)
        {
            var team = await _context.Teams
                .Include(t => t.TeamMembers)
                .SingleOrDefaultAsync(t => t.Id == teamId);

            if (team == null)
                throw new KeyNotFoundException("Nie znaleziono zespołu.");

            // Usuń powiązania TeamMembers
            _context.TeamMembers.RemoveRange(team.TeamMembers);

            // Usuń sam zespół
            _context.Teams.Remove(team);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateTeamMembersAsync(int teamId, List<int> userIds)
        {
            // 1) Usuń wszystkich obecnych członków z wybranego zespołu
            var existingMembers = _context.TeamMembers
                .Where(tm => tm.TeamId == teamId);
            _context.TeamMembers.RemoveRange(existingMembers);

            // 2) Dodaj nowych
            var distinctUserIds = userIds.Distinct().ToList();
            foreach (var uId in distinctUserIds)
            {
                _context.TeamMembers.Add(new TeamMember
                {
                    TeamId = teamId,
                    UserId = uId
                });
            }

            await _context.SaveChangesAsync();
        }
    }
}
