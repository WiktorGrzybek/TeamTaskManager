﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using TeamTaskManager.Data;
using TeamTaskManager.Models;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly AppDbContext _context;
        private readonly IServiceProvider _serviceProvider;
        public UserService(AppDbContext context, IServiceProvider serviceProvider)
        {
            _context = context;
            _serviceProvider = serviceProvider;
        }

        public async Task<bool> IsEmailAvailableAsync(string email)
        {
            return !await _context.Users.AnyAsync(u => u.Email.ToLower() == email.ToLower());
        }

        public async Task<User> AuthenticateAsync(string email, string password)
        {
            var user = await _context.Users
                .SingleOrDefaultAsync(u => u.Email.ToLower() == email.ToLower());

            if (user == null)
                return null;

            bool isValid = BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
            if (!isValid)
                return null;

            return user;
        }

        public async Task<User> CreateUserAsync(User newUser, string rawPassword)
        {
            // 1) Sprawdź, czy e-mail jest wolny
            if (!await IsEmailAvailableAsync(newUser.Email))
                throw new InvalidOperationException("Ten e-mail jest już zajęty.");

            // 2) (Przykład) walidacja kontekstowa (opcjonalnie)
            if (newUser.Country == "Polska")
            {
                // np. dodatkowa walidacja PESEL
            }

            // 3) Hashuj hasło
            newUser.PasswordHash = BCrypt.Net.BCrypt.HashPassword(rawPassword);

            // 4) Domyślna rola = Member (jeżeli przekazano nieprawidłową)
            if (!Enum.IsDefined(typeof(UserRole), newUser.Role))
                newUser.Role = UserRole.Member;

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            return await _context.Users.FindAsync(newUser.Id);
        }

        public async Task<List<User>> GetAllAsync()
        {
            using (var context = _serviceProvider.CreateScope())
            {
                var db = context.ServiceProvider.GetService<AppDbContext>();
                return await db.Users
                    .AsNoTracking()
                    .OrderBy(u => u.LastName).ThenBy(u => u.FirstName)
                    .ToListAsync();
            }
        }

        public async Task<User> GetByIdAsync(int userId)
        {
            var user = await _context.Users
                .Include(u => u.TeamMembers)
                    .ThenInclude(tm => tm.Team)
                .Include(u => u.TaskAssignments)
                    .ThenInclude(ta => ta.TaskItem)
                .SingleOrDefaultAsync(u => u.Id == userId);

            if (user == null)
                throw new KeyNotFoundException("Nie znaleziono użytkownika.");

            return user;
        }

        public async Task UpdateUserAsync(User user)
        {
            var existing = await _context.Users.FindAsync(user.Id);
            if (existing == null)
                throw new KeyNotFoundException("Nie znaleziono użytkownika.");

            existing.FirstName = user.FirstName;
            existing.LastName = user.LastName;
            existing.Country = user.Country;
            existing.Role = user.Role;

            _context.Users.Update(existing);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteUserAsync(int userId)
        {
            // Pobieramy użytkownika wraz ze wszystkimi powiązaniami
            var user = await _context.Users
                .Include(u => u.TeamMembers)
                .Include(u => u.TaskAssignments)
                .Include(u => u.CreatedTeams)
                .Include(u => u.CreatedTasks)
                .SingleOrDefaultAsync(u => u.Id == userId);

            if (user == null)
                throw new KeyNotFoundException("Nie znaleziono użytkownika.");

            // 1) Usuń wszystkie TeamMembers
            _context.TeamMembers.RemoveRange(user.TeamMembers);

            // 2) Usuń wszystkie TaskAssignments
            _context.TaskAssignments.RemoveRange(user.TaskAssignments);

            // 3) Usuń wszystkie zadania, które ten użytkownik utworzył:
            if (user.CreatedTasks != null && user.CreatedTasks.Any())
            {
                // Najpierw usuwamy wszelkie zadania wraz z taskAssignments i progresses (kaskadowo)
                _context.TaskItems.RemoveRange(user.CreatedTasks);
            }

            // 4) Usuń wszystkie zespoły, które ten użytkownik utworzył:
            if (user.CreatedTeams != null && user.CreatedTeams.Any())
            {
                // Przed usunięciem zespołu musimy usunąć TeamMembers wewnątrz nich
                foreach (var team in user.CreatedTeams)
                {
                    // Pobieramy pełne Team wraz z TeamMembers
                    var fullTeam = await _context.Teams
                        .Include(t => t.TeamMembers)
                        .SingleOrDefaultAsync(t => t.Id == team.Id);

                    if (fullTeam != null)
                    {
                        _context.TeamMembers.RemoveRange(fullTeam.TeamMembers);
                        _context.Teams.Remove(fullTeam);
                    }
                }
            }

            // 5) Usuń samego użytkownika
            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
        }
    }
}
