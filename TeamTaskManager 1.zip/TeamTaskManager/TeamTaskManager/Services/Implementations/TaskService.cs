﻿// File: Services/Implementations/TaskService.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TeamTaskManager.Data;
using TeamTaskManager.Models;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Services.Implementations
{
    public class TaskService : ITaskService
    {
        private readonly AppDbContext _context;

        public TaskService(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Pobiera wszystkie zadania wraz z powiązaniami: Team, CreatedByUser, TaskAssignments i Progresses.
        /// </summary>
        public async Task<List<TaskItem>> GetAllAsync()
        {
            return await _context.TaskItems
                .Include(t => t.Team)
                .Include(t => t.CreatedByUser)
                .Include(t => t.TaskAssignments)
                    .ThenInclude(ta => ta.User)
                .Include(t => t.Progresses)
                .AsNoTracking()
                .ToListAsync();
        }

        /// <summary>
        /// Pobiera pojedyncze zadanie (po Id) wraz z detalami: Team, CreatedByUser, TaskAssignments i Progresses.
        /// </summary>
        public async Task<TaskItem> GetByIdAsync(int taskId)
        {
            return await _context.TaskItems
                .Include(t => t.Team)
                .Include(t => t.CreatedByUser)
                .Include(t => t.TaskAssignments)
                    .ThenInclude(ta => ta.User)
                .Include(t => t.Progresses)
                .FirstOrDefaultAsync(t => t.Id == taskId);
        }

        /// <summary>
        /// Tworzy nowe zadanie; automatycznie dodaje wpis w Progress i przypisuje użytkowników.
        /// </summary>
        public async Task<TaskItem> CreateTaskAsync(TaskItem task, List<int> assignedUserIds)
        {
            // 1. Dodajemy TaskItem (ustawiamy CreatedAt i CurrentStatus)
            task.CreatedAt = DateTime.UtcNow.ToUniversalTime();
            task.CurrentStatus = string.IsNullOrWhiteSpace(task.CurrentStatus)
                                 ? "Nierozpoczęte"
                                 : task.CurrentStatus;
            task.DueDate = task.DueDate.ToUniversalTime();
            _context.TaskItems.Add(task);
            await _context.SaveChangesAsync();

            // 2. Dodajemy TaskAssignments (jeśli są wybrani użytkownicy)
            if (assignedUserIds != null && assignedUserIds.Count > 0)
            {
                var assignments = assignedUserIds
                    .Select(uId => new TaskAssignment
                    {
                        TaskItemId = task.Id,
                        UserId = uId
                    }).ToList();
                _context.TaskAssignments.AddRange(assignments);
            }

            // 3. Dodajemy początkowy wpis w Progress
            var initialProgress = new Progress
            {
                TaskItemId = task.Id,
                Status = task.CurrentStatus,
                Comment = "Zadanie utworzone",
                Timestamp = DateTime.UtcNow
            };
            _context.Progresses.Add(initialProgress);

            await _context.SaveChangesAsync();

            return await GetByIdAsync(task.Id);
        }

        /// <summary>
        /// Aktualizuje pola zadania i przypisania użytkowników. Nie zmieniamy CurrentStatus tutaj.
        /// </summary>
        public async Task UpdateTaskAsync(TaskItem task, List<int> assignedUserIds)
        {
            var existing = await _context.TaskItems
                .Include(t => t.TaskAssignments)
                .FirstOrDefaultAsync(t => t.Id == task.Id);

            if (existing == null)
                throw new InvalidOperationException("Zadanie nie zostało znalezione.");

            existing.Title = task.Title;
            existing.Description = task.Description;
            existing.DueDate = task.DueDate;
            existing.TeamId = task.TeamId;
            existing.CurrentStatus = task.CurrentStatus;

            // Synchronizacja TaskAssignments:
            var currentAssigned = existing.TaskAssignments.Select(ta => ta.UserId).ToList();
            var toAdd = assignedUserIds.Except(currentAssigned).ToList();
            var toRemove = currentAssigned.Except(assignedUserIds).ToList();

            if (toAdd.Any())
            {
                var newAssignments = toAdd
                    .Select(uId => new TaskAssignment
                    {
                        TaskItemId = existing.Id,
                        UserId = uId
                    });
                _context.TaskAssignments.AddRange(newAssignments);
            }

            if (toRemove.Any())
            {
                var removeEntities = _context.TaskAssignments
                    .Where(ta => ta.TaskItemId == existing.Id && toRemove.Contains(ta.UserId));
                _context.TaskAssignments.RemoveRange(removeEntities);
            }

            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Usuwa zadanie wraz z wszystkimi relacjami (kaskadowo).
        /// </summary>
        public async Task DeleteTaskAsync(int taskId)
        {
            var task = await _context.TaskItems
                .Include(t => t.TaskAssignments)
                .Include(t => t.Progresses)
                .FirstOrDefaultAsync(t => t.Id == taskId);

            if (task == null)
                throw new InvalidOperationException("Zadanie nie zostało znalezione.");

            _context.TaskItems.Remove(task);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Dodaje wpis w historii Progress i jednocześnie aktualizuje CurrentStatus w TaskItem.
        /// </summary>
        public async Task AddProgressAsync(int taskId, Progress progress)
        {
            var task = await _context.TaskItems.FindAsync(taskId);
            if (task == null)
                throw new InvalidOperationException("Zadanie nie zostało znalezione.");

            progress.TaskItemId = taskId;
            progress.Timestamp = DateTime.UtcNow;

            _context.Progresses.Add(progress);

            // Aktualizacja statusu zadania
            task.CurrentStatus = progress.Status;

            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Pobiera historię Progress dla zadanego zadania (kolejność od najstarszego).
        /// </summary>
        public async Task<List<Progress>> GetProgressHistoryAsync(int taskId)
        {
            return await _context.Progresses
                .Where(p => p.TaskItemId == taskId)
                .OrderBy(p => p.Timestamp)
                .ToListAsync();
        }

        /// <summary>
        /// Opcjonalne filtrowanie zadań po: zespole, użytkowniku, terminie, statusie.
        /// </summary>
        public async Task<List<TaskItem>> FilterTasksAsync(int? teamId, int? userId, DateTime? dueBefore, string status)
        {
            IQueryable<TaskItem> query = _context.TaskItems
                .Include(t => t.Team)
                .Include(t => t.CreatedByUser)
                .Include(t => t.TaskAssignments)
                    .ThenInclude(ta => ta.User)
                .Include(t => t.Progresses);

            if (teamId.HasValue)
                query = query.Where(t => t.TeamId == teamId.Value);
            if (userId.HasValue)
                query = query.Where(t => t.TaskAssignments.Any(ta => ta.UserId == userId.Value));
            if (dueBefore.HasValue)
                query = query.Where(t => t.DueDate <= dueBefore.Value);
            if (!string.IsNullOrEmpty(status))
                query = query.Where(t => t.CurrentStatus == status);

            return await query.ToListAsync();
        }
    }
}
