﻿namespace TeamTaskManager.Models
{
    // Tabela łącznikowa Users <-> Teams (N:M)
    public class TeamMember
    {
        public int UserId { get; set; }
        public virtual User User { get; set; }

        public int TeamId { get; set; }
        public virtual Team Team { get; set; }
    }
}
