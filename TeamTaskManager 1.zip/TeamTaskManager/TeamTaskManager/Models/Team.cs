﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TeamTaskManager.Models
{
    public class Team
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        [MaxLength(500)]
        public string Description { get; set; }
        public int CreatedByUserId { get; set; }
        public User CreatedByUser { get; set; }
        // Nawigacyjne
        public virtual ICollection<TeamMember> TeamMembers { get; set; } = new List<TeamMember>();
        public virtual ICollection<TaskItem> TaskItems { get; set; } = new List<TaskItem>();
    }
}
