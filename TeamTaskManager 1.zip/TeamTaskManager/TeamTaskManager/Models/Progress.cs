﻿// Models/Progress.cs
using System;
using System.ComponentModel.DataAnnotations;

namespace TeamTaskManager.Models
{
    public class Progress
    {
        public int Id { get; set; }

        [Required, MaxLength(50)]
        public string Status { get; set; } // np. "Nowe", "W toku", "Zakończone"

        [MaxLength(500)]
        public string Comment { get; set; } // opcjonalny komentarz

        [Required]
        public DateTime Timestamp { get; set; }

        // Relacja do zadania
        public int TaskItemId { get; set; }
        public virtual TaskItem TaskItem { get; set; }
    }
}
