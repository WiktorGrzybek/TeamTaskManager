﻿// User.cs
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TeamTaskManager.Models
{
    public enum UserRole
    {
        Admin,
        Member
    }

    public class User
    {
        public int Id { get; set; }

        [Required, EmailAddress, MaxLength(150)]
        public string Email { get; set; }

        [Required]
        public string PasswordHash { get; set; } // Hash hasła, nie przechowujemy jawnie

        [Required, MaxLength(50)]
        public string FirstName { get; set; }

        [Required, MaxLength(50)]
        public string LastName { get; set; }

        [MaxLength(50)]
        public string Country { get; set; }

        [Required]
        public UserRole Role { get; set; }

        // Kolekcja zespołów utworzonych przez tego użytkownika
        public ICollection<Team> CreatedTeams { get; set; } = new List<Team>();

        // Kolekcja zadań utworzonych przez tego użytkownika
        public ICollection<TaskItem> CreatedTasks { get; set; } = new List<TaskItem>();

        // Nawigacyjne
        public virtual ICollection<TeamMember> TeamMembers { get; set; } = new List<TeamMember>();
        public virtual ICollection<TaskAssignment> TaskAssignments { get; set; } = new List<TaskAssignment>();
    }
}
