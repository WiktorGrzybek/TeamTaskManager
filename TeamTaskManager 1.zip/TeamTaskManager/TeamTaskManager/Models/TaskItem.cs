﻿// Models/TaskItem.cs
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TeamTaskManager.Models
{
    public class TaskItem
    {
        public int Id { get; set; }

        [Required, MaxLength(200)]
        public string Title { get; set; }

        [MaxLength(1000)]
        public string Description { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; }

        [Required]
        public DateTime DueDate { get; set; }

        // Pole „pomocnicze” na bieżący status (synchronizowane z ostatnim wpisem Progress)
        [MaxLength(50)]
        public string CurrentStatus { get; set; }

        [Required]
        public int CreatedByUserId { get; set; }
        public virtual User CreatedByUser { get; set; }

        // Klucz obcy do zespołu
        public int TeamId { get; set; }
        public virtual Team Team { get; set; }

        // Powiązania
        public virtual ICollection<TaskAssignment> TaskAssignments { get; set; } = new List<TaskAssignment>();
        public virtual ICollection<Progress> Progresses { get; set; } = new List<Progress>();
    }
}
