﻿// File: Forms/TaskForm.Designer.cs

namespace TeamTaskManager.Forms
{
    partial class TaskForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.DataGridView dgvTasks;
        private System.Windows.Forms.GroupBox gbTaskDetails;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblDueDate;
        private System.Windows.Forms.DateTimePicker dtpDueDate;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.ComboBox cmbTeam;
        private System.Windows.Forms.Label lblAssignedUsers;
        private System.Windows.Forms.CheckedListBox clbAssignedUsers;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ComboBox cmbStatus;

        private System.Windows.Forms.GroupBox gbProgressHistory;
        private System.Windows.Forms.DataGridView dgvProgress;
        private System.Windows.Forms.Label lblProgressStatus;
        private System.Windows.Forms.ComboBox cmbProgressStatus;
        private System.Windows.Forms.TextBox txtProgressComment;
        private System.Windows.Forms.Button btnAddProgress;

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblMode;

        /// <summary>
        /// Wyczyść wszystkie użyte zasoby.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.dgvTasks = new System.Windows.Forms.DataGridView();
            this.gbTaskDetails = new System.Windows.Forms.GroupBox();
            this.lblId = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblDueDate = new System.Windows.Forms.Label();
            this.dtpDueDate = new System.Windows.Forms.DateTimePicker();
            this.lblTeam = new System.Windows.Forms.Label();
            this.cmbTeam = new System.Windows.Forms.ComboBox();
            this.lblAssignedUsers = new System.Windows.Forms.Label();
            this.clbAssignedUsers = new System.Windows.Forms.CheckedListBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();

            this.gbProgressHistory = new System.Windows.Forms.GroupBox();
            this.dgvProgress = new System.Windows.Forms.DataGridView();
            this.lblProgressStatus = new System.Windows.Forms.Label();
            this.cmbProgressStatus = new System.Windows.Forms.ComboBox();
            this.txtProgressComment = new System.Windows.Forms.TextBox();
            this.btnAddProgress = new System.Windows.Forms.Button();

            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblMode = new System.Windows.Forms.Label();

            this.SuspendLayout();
            // 
            // dgvTasks
            // 
            this.dgvTasks.Location = new System.Drawing.Point(20, 20);
            this.dgvTasks.Size = new System.Drawing.Size(740, 180);
            this.dgvTasks.ReadOnly = true;
            this.dgvTasks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTasks.MultiSelect = false;
            this.dgvTasks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTasks.Name = "dgvTasks";
            this.dgvTasks.AllowUserToAddRows = false;
            this.dgvTasks.AllowUserToDeleteRows = false;
            this.dgvTasks.AllowUserToResizeRows = false;
            this.dgvTasks.RowHeadersVisible = false;
            this.dgvTasks.SelectionChanged += new System.EventHandler(this.dgvTasks_SelectionChanged);
            // 
            // gbTaskDetails
            // 
            this.gbTaskDetails.Text = "Szczegóły zadania";
            this.gbTaskDetails.Location = new System.Drawing.Point(20, 220);
            this.gbTaskDetails.Size = new System.Drawing.Size(500, 350);
            this.gbTaskDetails.Name = "gbTaskDetails";
            // 
            // lblId
            // 
            this.lblId.Text = "ID:";
            this.lblId.Location = new System.Drawing.Point(20, 30);
            this.lblId.AutoSize = true;
            this.lblId.Name = "lblId";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(100, 28);
            this.txtId.Size = new System.Drawing.Size(100, 23);
            this.txtId.ReadOnly = true;
            this.txtId.Name = "txtId";
            // 
            // lblTitle
            // 
            this.lblTitle.Text = "Tytuł:";
            this.lblTitle.Location = new System.Drawing.Point(20, 60);
            this.lblTitle.AutoSize = true;
            this.lblTitle.Name = "lblTitle";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(100, 58);
            this.txtTitle.Size = new System.Drawing.Size(350, 23);
            this.txtTitle.Name = "txtTitle";
            // 
            // lblDescription
            // 
            this.lblDescription.Text = "Opis:";
            this.lblDescription.Location = new System.Drawing.Point(20, 90);
            this.lblDescription.AutoSize = true;
            this.lblDescription.Name = "lblDescription";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(100, 88);
            this.txtDescription.Size = new System.Drawing.Size(350, 80);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            // 
            // lblDueDate
            // 
            this.lblDueDate.Text = "Termin:";
            this.lblDueDate.Location = new System.Drawing.Point(20, 180);
            this.lblDueDate.AutoSize = true;
            this.lblDueDate.Name = "lblDueDate";
            // 
            // dtpDueDate
            // 
            this.dtpDueDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDueDate.Location = new System.Drawing.Point(100, 178);
            this.dtpDueDate.Size = new System.Drawing.Size(120, 23);
            this.dtpDueDate.Name = "dtpDueDate";
            // 
            // lblTeam
            // 
            this.lblTeam.Text = "Zespół:";
            this.lblTeam.Location = new System.Drawing.Point(20, 210);
            this.lblTeam.AutoSize = true;
            this.lblTeam.Name = "lblTeam";
            // 
            // cmbTeam
            // 
            this.cmbTeam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTeam.Location = new System.Drawing.Point(100, 208);
            this.cmbTeam.Size = new System.Drawing.Size(200, 23);
            this.cmbTeam.Name = "cmbTeam";
            // 
            // lblAssignedUsers
            // 
            this.lblAssignedUsers.Text = "Przypisani użytkownicy:";
            this.lblAssignedUsers.Location = new System.Drawing.Point(20, 240);
            this.lblAssignedUsers.AutoSize = true;
            this.lblAssignedUsers.Name = "lblAssignedUsers";
            // 
            // clbAssignedUsers
            // 
            this.clbAssignedUsers.CheckOnClick = true;
            this.clbAssignedUsers.Location = new System.Drawing.Point(20, 260);
            this.clbAssignedUsers.Size = new System.Drawing.Size(200, 80);
            this.clbAssignedUsers.Name = "clbAssignedUsers";
            // 
            // lblStatus
            // 
            this.lblStatus.Text = "Status zadania:";
            this.lblStatus.Location = new System.Drawing.Point(20, 350);
            this.lblStatus.AutoSize = true;
            this.lblStatus.Name = "lblStatus";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Location = new System.Drawing.Point(100, 348);
            this.cmbStatus.Size = new System.Drawing.Size(120, 23);
            this.cmbStatus.Name = "cmbStatus";
            // 
            this.gbTaskDetails.Controls.Add(this.lblId);
            this.gbTaskDetails.Controls.Add(this.txtId);
            this.gbTaskDetails.Controls.Add(this.lblTitle);
            this.gbTaskDetails.Controls.Add(this.txtTitle);
            this.gbTaskDetails.Controls.Add(this.lblDescription);
            this.gbTaskDetails.Controls.Add(this.txtDescription);
            this.gbTaskDetails.Controls.Add(this.lblDueDate);
            this.gbTaskDetails.Controls.Add(this.dtpDueDate);
            this.gbTaskDetails.Controls.Add(this.lblTeam);
            this.gbTaskDetails.Controls.Add(this.cmbTeam);
            this.gbTaskDetails.Controls.Add(this.lblAssignedUsers);
            this.gbTaskDetails.Controls.Add(this.clbAssignedUsers);
            this.gbTaskDetails.Controls.Add(this.lblStatus);
            this.gbTaskDetails.Controls.Add(this.cmbStatus);

            // 
            // gbProgressHistory
            // 
            this.gbProgressHistory.Text = "Historia postępów";
            this.gbProgressHistory.Location = new System.Drawing.Point(540, 220);
            this.gbProgressHistory.Size = new System.Drawing.Size(220, 350);
            this.gbProgressHistory.Name = "gbProgressHistory";
            // 
            // dgvProgress
            // 
            this.dgvProgress.Location = new System.Drawing.Point(10, 25);
            this.dgvProgress.Size = new System.Drawing.Size(200, 150);
            this.dgvProgress.ReadOnly = true;
            this.dgvProgress.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProgress.MultiSelect = false;
            this.dgvProgress.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProgress.Name = "dgvProgress";
            this.dgvProgress.AllowUserToAddRows = false;
            this.dgvProgress.AllowUserToDeleteRows = false;
            this.dgvProgress.AllowUserToResizeRows = false;
            this.dgvProgress.RowHeadersVisible = false;
            // 
            // lblProgressStatus
            // 
            this.lblProgressStatus.Text = "Status:";
            this.lblProgressStatus.Location = new System.Drawing.Point(10, 180);
            this.lblProgressStatus.AutoSize = true;
            this.lblProgressStatus.Name = "lblProgressStatus";
            // 
            // cmbProgressStatus
            // 
            this.cmbProgressStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProgressStatus.Location = new System.Drawing.Point(60, 177);
            this.cmbProgressStatus.Size = new System.Drawing.Size(150, 23);
            this.cmbProgressStatus.Name = "cmbProgressStatus";
            // 
            // txtProgressComment
            // 
            this.txtProgressComment.Location = new System.Drawing.Point(10, 210);
            this.txtProgressComment.Size = new System.Drawing.Size(200, 23);
            this.txtProgressComment.Name = "txtProgressComment";
            this.txtProgressComment.PlaceholderText = "Komentarz";
            // 
            // btnAddProgress
            // 
            this.btnAddProgress.Text = "Dodaj postęp";
            this.btnAddProgress.Location = new System.Drawing.Point(10, 240);
            this.btnAddProgress.Size = new System.Drawing.Size(200, 30);
            this.btnAddProgress.Name = "btnAddProgress";
            this.btnAddProgress.Click += new System.EventHandler(this.btnAddProgress_Click);

            this.gbProgressHistory.Controls.Add(this.dgvProgress);
            this.gbProgressHistory.Controls.Add(this.lblProgressStatus);
            this.gbProgressHistory.Controls.Add(this.cmbProgressStatus);
            this.gbProgressHistory.Controls.Add(this.txtProgressComment);
            this.gbProgressHistory.Controls.Add(this.btnAddProgress);

            // 
            // btnAdd
            // 
            this.btnAdd.Text = "Dodaj";
            this.btnAdd.Location = new System.Drawing.Point(20, 600);
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSave
            // 
            this.btnSave.Text = "Zapisz";
            this.btnSave.Location = new System.Drawing.Point(140, 600);
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.Name = "btnSave";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Text = "Usuń";
            this.btnDelete.Location = new System.Drawing.Point(260, 600);
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Text = "Anuluj";
            this.btnCancel.Location = new System.Drawing.Point(380, 600);
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblMode
            // 
            this.lblMode.Text = "";
            this.lblMode.Location = new System.Drawing.Point(520, 605);
            this.lblMode.AutoSize = true;
            this.lblMode.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblMode.Name = "lblMode";
            // 
            // TaskForm
            // 
            this.ClientSize = new System.Drawing.Size(780, 650);
            this.Controls.Add(this.dgvTasks);
            this.Controls.Add(this.gbTaskDetails);
            this.Controls.Add(this.gbProgressHistory);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblMode);

            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TaskForm";
            this.Text = "Zarządzanie zadaniami";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Load += new System.EventHandler(this.TaskForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
