﻿using System;
using System.Drawing;
using System.Windows.Forms;
using TeamTaskManager.Services.Interfaces;
using TeamTaskManager.Models;

namespace TeamTaskManager.Forms
{
    public partial class MainForm : Form
    {
        private readonly IUserService _userService;
        private readonly ITeamService _teamService;
        private readonly ITaskService _taskService;
        private readonly UserSession _currentUser;

        public MainForm(
            IUserService userService,
            ITeamService teamService,
            ITaskService taskService,
            UserSession currentUser)
        {
            InitializeComponent();

            _userService = userService;
            _teamService = teamService;
            _taskService = taskService;
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));

            // Ustawienia wizualne formy
            this.BackColor = Color.White;
            panelTop.BackColor = Color.FromArgb(30, 144, 255);
            lblWelcome.ForeColor = Color.White;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = $"Witaj, {_currentUser.FullName} ({_currentUser.Role})";

            // Zamiast całkowicie wyłączać przycisk, tylko zmieniamy jego wygląd.
            // Każdy zobaczy pasek i będzie mógł otworzyć UserForm, ale w UserForm od razu w trybie View.
            if (_currentUser.Role != UserRole.Admin)
            {
                btnManageUsers.BackColor = Color.LightGray;
                btnManageUsers.ForeColor = Color.DarkGray;
                btnManageUsers.Cursor = Cursors.Hand; // nadal można kliknąć
                toolTip.SetToolTip(btnManageUsers, "Tylko administrator może edytować użytkowników, inni wyświetlają w trybie podglądu");
            }
        }

        private void btnManageUsers_Click(object sender, EventArgs e)
        {
            // Niezależnie od roli – otwieramy formularz.
            // Wewnątrz UserForm zabezpieczenia uniemożliwią edycję nie-adminom.
            using (var uf = new UserForm(_userService, _currentUser))
            {
                uf.ShowDialog();
            }
        }

        private void btnManageTeams_Click(object sender, EventArgs e)
        {
            using (var tf = new TeamForm(_teamService, _userService, _currentUser))
            {
                tf.ShowDialog();
            }
        }

        private void btnManageTasks_Click(object sender, EventArgs e)
        {
            using (var taskf = new TaskForm(_taskService, _teamService, _userService, _currentUser))
            {
                taskf.ShowDialog();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
