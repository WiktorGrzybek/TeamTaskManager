﻿// File: Forms/TeamForm.cs

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeamTaskManager.Models;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Forms
{
    public partial class TeamForm : Form
    {
        private readonly ITeamService _teamService;
        private readonly IUserService _userService;
        private readonly UserSession _currentUser;
        private bool _isAddingNew = false;
        private bool _isEditing = false;   // flaga, czy jesteśmy w trybie edycji istniejącego zespołu

        public TeamForm(ITeamService teamService, IUserService userService, UserSession currentUser)
        {
            InitializeComponent();
            _teamService = teamService;
            _userService = userService;
            _currentUser = currentUser;

            // Ustawienia wizualne:
            this.BackColor = Color.White;
            dgvTeams.BackgroundColor = Color.WhiteSmoke;
            gbDetails.BackColor = Color.WhiteSmoke;
        }

        private async void TeamForm_Load(object sender, EventArgs e)
        {
            await LoadTeamsAsync();
            SetMode(ViewMode.View);
        }

        private async Task LoadTeamsAsync()
        {
            try
            {
                // Pobierz wszystkie zespoły wraz z powiązaniami (TeamMembers, CreatedByUser, TaskItems)
                var teams = await _teamService.GetAllAsync();

                // Tworzymy projekcję anonimową, aby wyświetlić:
                // Id, Name, Description, CreatedBy (imię + nazwisko), MemberCount, TaskCount, CreatedByUserId (ukryte)
                var displayList = teams
                    .Select(t => new
                    {
                        t.Id,
                        t.Name,
                        t.Description,
                        CreatedBy = t.CreatedByUser.FirstName + " " + t.CreatedByUser.LastName,
                        MemberCount = t.TeamMembers.Count,
                        TaskCount = t.TaskItems.Count,
                        CreatedByUserId = t.CreatedByUserId
                    })
                    .ToList();

                dgvTeams.DataSource = displayList;

                // Styl nagłówków:
                dgvTeams.EnableHeadersVisualStyles = false;
                dgvTeams.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(230, 230, 250);
                dgvTeams.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);

                // Ustawienie headerów i ukrycie niektórych kolumn
                if (dgvTeams.Columns.Contains("CreatedBy"))
                    dgvTeams.Columns["CreatedBy"].HeaderText = "Utworzył";
                if (dgvTeams.Columns.Contains("MemberCount"))
                    dgvTeams.Columns["MemberCount"].HeaderText = "Liczba członków";
                if (dgvTeams.Columns.Contains("TaskCount"))
                    dgvTeams.Columns["TaskCount"].HeaderText = "Liczba zadań";

                // Ukryj kolumnę CreatedByUserId (potrzebna wewnętrznie do sprawdzeń uprawnień)
                if (dgvTeams.Columns.Contains("CreatedByUserId"))
                    dgvTeams.Columns["CreatedByUserId"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas ładowania zespołów: {ex.Message}",
                                "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void dgvTeams_SelectionChanged(object sender, EventArgs e)
        {
            if ((!_isAddingNew && !_isEditing) && dgvTeams.SelectedRows.Count > 0)
            {
                int selectedId = (int)dgvTeams.SelectedRows[0].Cells["Id"].Value;
                var team = await _teamService.GetByIdAsync(selectedId);

                if (team != null)
                {
                    // Uzupełnij szczegóły
                    txtId.Text = team.Id.ToString();
                    txtName.Text = team.Name;
                    txtDescription.Text = team.Description;

                    // W trybie Podgląd (domyślnie) wypełnij listę członków, ale wyłącz możliwość zaznaczania
                    clbMembers.Items.Clear();
                    clbMembers.Enabled = false;

                    if (team.TeamMembers != null)
                    {
                        var allUsers = await _userService.GetAllAsync();
                        foreach (var u in allUsers)
                        {
                            int idx = clbMembers.Items.Add(new TeamComboBoxItem(u.Id, $"{u.FirstName} {u.LastName}"));
                            if (team.TeamMembers.Any(tm => tm.UserId == u.Id))
                                clbMembers.SetItemChecked(idx, true);
                        }
                    }

                    lblMode.Text = "Tryb: Podgląd";
                }
            }
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            _isAddingNew = true;
            _isEditing = false;
            SetMode(ViewMode.Add);
            ClearFields();

            // W trybie Dodawania: uaktywnij czyszczenie i wypełnij checkboxy
            clbMembers.Items.Clear();
            clbMembers.Enabled = true;
            var users = await _userService.GetAllAsync();
            foreach (var u in users)
            {
                clbMembers.Items.Add(new TeamComboBoxItem(u.Id, $"{u.FirstName} {u.LastName}"));
            }
        }

        private async void btnEdit_Click(object sender, EventArgs e)
        {
            // Przycisk „Edytuj” – włącza tryb edycji dla już zaznaczonego zespołu
            if (dgvTeams.SelectedRows.Count == 0)
                return;

            int selectedId = (int)dgvTeams.SelectedRows[0].Cells["Id"].Value;
            var team = await _teamService.GetByIdAsync(selectedId);
            if (team == null)
                return;

            // Sprawdź uprawnienia przed edycją
            int createdById = (int)dgvTeams.SelectedRows[0].Cells["CreatedByUserId"].Value;
            if (_currentUser.Role != UserRole.Admin && createdById != _currentUser.UserId)
            {
                MessageBox.Show("Brak uprawnień. Tylko właściciel lub administrator może edytować ten zespół.",
                                "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _isAddingNew = false;
            _isEditing = true;
            SetMode(ViewMode.Edit);

            // W trybie Edycji: wypełnij pola i checkboxy aktywne
            txtId.Text = team.Id.ToString();
            txtName.Text = team.Name;
            txtDescription.Text = team.Description;

            clbMembers.Items.Clear();
            clbMembers.Enabled = true;
            var allUsers = await _userService.GetAllAsync();
            foreach (var u in allUsers)
            {
                int idx = clbMembers.Items.Add(new TeamComboBoxItem(u.Id, $"{u.FirstName} {u.LastName}"));
                if (team.TeamMembers.Any(tm => tm.UserId == u.Id))
                    clbMembers.SetItemChecked(idx, true);
            }

            lblMode.Text = "Tryb: Edycja";
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (_isAddingNew)
            {
                // Dodanie nowego zespołu
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Pole Nazwa jest wymagane.", "Uwaga", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtName.Focus();
                    return;
                }

                var newTeam = new Team
                {
                    Name = txtName.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    CreatedByUserId = _currentUser.UserId
                };

                try
                {
                    // 1) Tworzymy zespół:
                    var createdTeam = await _teamService.CreateTeamAsync(newTeam);

                    // 2) Przypisujemy zaznaczonych użytkowników:
                    var selectedUserIds = new List<int>();
                    for (int i = 0; i < clbMembers.Items.Count; i++)
                    {
                        if (clbMembers.GetItemChecked(i))
                        {
                            var cbi = (TeamComboBoxItem)clbMembers.Items[i];
                            selectedUserIds.Add(cbi.Id);
                        }
                    }

                    if (selectedUserIds.Count > 0)
                    {
                        await _teamService.UpdateTeamMembersAsync(createdTeam.Id, selectedUserIds);
                    }

                    await LoadTeamsAsync();
                    SetMode(ViewMode.View);
                    _isAddingNew = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas dodawania zespołu: {ex.Message}", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (_isEditing)
            {
                // Zapis edytowanego zespołu
                if (!int.TryParse(txtId.Text, out int teamId))
                    return;

                if (_currentUser.Role != UserRole.Admin)
                {
                    // Dodatkowa weryfikacja: tylko właściciel lub Admin
                    int createdById = (int)dgvTeams.SelectedRows[0].Cells["CreatedByUserId"].Value;
                    if (createdById != _currentUser.UserId)
                    {
                        MessageBox.Show("Brak uprawnień. Tylko właściciel lub administrator może zapisać zmiany.", "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                try
                {
                    var existing = await _teamService.GetByIdAsync(teamId);
                    if (existing != null)
                    {
                        // Zaktualizuj nazwę i opis
                        existing.Name = txtName.Text.Trim();
                        existing.Description = txtDescription.Text.Trim();
                        await _teamService.UpdateTeamAsync(existing);

                        // Zaktualizuj członków
                        var selectedUserIds = new List<int>();
                        foreach (int idx in clbMembers.CheckedIndices)
                        {
                            var cbi = (TeamComboBoxItem)clbMembers.Items[idx];
                            selectedUserIds.Add(cbi.Id);
                        }
                        await _teamService.UpdateTeamMembersAsync(teamId, selectedUserIds);

                        await LoadTeamsAsync();
                        SetMode(ViewMode.View);
                        _isEditing = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas aktualizacji zespołu: {ex.Message}", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            // W trybie „View” przycisk Save jest wyłączony, więc nie obsługujemy tej sytuacji tutaj.
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out int teamId))
                return;

            var toDelete = await _teamService.GetByIdAsync(teamId);
            if (toDelete == null)
                return;

            // Sprawdzenie uprawnień:
            int createdById = (int)dgvTeams.SelectedRows[0].Cells["CreatedByUserId"].Value;
            if (_currentUser.Role != UserRole.Admin && createdById != _currentUser.UserId)
            {
                MessageBox.Show("Brak uprawnień. Możesz usuwać tylko własne zespoły.", "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var confirm = MessageBox.Show(
                "Na pewno chcesz usunąć zespół? Wszystkie powiązane rekordy (członkowie itp.) zostaną usunięte.",
                "Potwierdzenie",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                try
                {
                    await _teamService.DeleteTeamAsync(teamId);
                    await LoadTeamsAsync();
                    ClearFields();
                    SetMode(ViewMode.View);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas usuwania: {ex.Message}", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _isAddingNew = false;
            _isEditing = false;
            SetMode(ViewMode.View);
            ClearFields();
        }

        private void SetMode(ViewMode mode)
        {
            if (mode == ViewMode.View)
            {
                // Wyłącz edycję pól w trybie podglądu
                txtId.ReadOnly = true;
                txtName.ReadOnly = true;
                txtDescription.ReadOnly = true;
                clbMembers.Enabled = false;

                // Przyciski
                btnAdd.Enabled = true;
                btnSave.Enabled = false;
                btnDelete.Enabled = (dgvTeams.SelectedRows.Count > 0);
                btnEdit.Enabled = (dgvTeams.SelectedRows.Count > 0);
                btnCancel.Enabled = false;
                lblMode.Text = "Tryb: Podgląd";

                if (dgvTeams.SelectedRows.Count > 0)
                {
                    int createdById = (int)dgvTeams.SelectedRows[0].Cells["CreatedByUserId"].Value;
                    if (_currentUser.Role != UserRole.Admin && createdById != _currentUser.UserId)
                    {
                        btnDelete.Enabled = false;
                        btnEdit.Enabled = false;
                    }
                }
            }
            else if (mode == ViewMode.Add)
            {
                // Tryb dodawania nowego zespołu
                txtId.ReadOnly = true;
                txtName.ReadOnly = false;
                txtDescription.ReadOnly = false;
                clbMembers.Enabled = true;

                btnAdd.Enabled = false;
                btnSave.Enabled = true;    // włączamy „Zapisz” aby móc dodać
                btnDelete.Enabled = false;
                btnEdit.Enabled = false;
                btnCancel.Enabled = true;
                lblMode.Text = "Tryb: Dodawanie";
            }
            else // ViewMode.Edit
            {
                // Tryb edycji istniejącego zespołu
                txtId.ReadOnly = true;
                txtName.ReadOnly = false;
                txtDescription.ReadOnly = false;
                clbMembers.Enabled = true;

                btnAdd.Enabled = false;
                btnSave.Enabled = true;    // przycisk „Zapisz” teraz zapisuje edycję
                btnDelete.Enabled = false;
                btnEdit.Enabled = false;
                btnCancel.Enabled = true;
                lblMode.Text = "Tryb: Edycja";
            }
        }

        private void ClearFields()
        {
            txtId.Text = string.Empty;
            txtName.Text = string.Empty;
            txtDescription.Text = string.Empty;
            clbMembers.Items.Clear();
        }

        private enum ViewMode
        {
            View,
            Add,
            Edit
        }
    }

    /// <summary>
    /// Pomocnicza klasa do przechowywania Id i Tekstu w CheckedListBox w TeamForm
    /// </summary>
    public class TeamComboBoxItem
    {
        public int Id { get; set; }
        public string Text { get; set; }

        public TeamComboBoxItem(int id, string text)
        {
            Id = id;
            Text = text;
        }

        public override string ToString()
        {
            return Text;
        }
    }
}
