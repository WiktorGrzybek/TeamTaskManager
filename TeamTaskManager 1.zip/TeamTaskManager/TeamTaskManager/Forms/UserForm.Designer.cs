﻿// File: Forms/UserForm.Designer.cs

namespace TeamTaskManager.Forms
{
    partial class UserForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.GroupBox gbDetails;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdit;    // NOWY: przycisk Edytuj
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblMode;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta

        private void InitializeComponent()
        {
            dgvUsers = new DataGridView();
            gbDetails = new GroupBox();
            tableLayoutPanel2 = new TableLayoutPanel();
            lblId = new Label();
            txtId = new TextBox();
            lblEmail = new Label();
            txtEmail = new TextBox();
            lblFirstName = new Label();
            txtFirstName = new TextBox();
            lblLastName = new Label();
            txtLastName = new TextBox();
            lblCountry = new Label();
            txtCountry = new TextBox();
            lblRole = new Label();
            cmbRole = new ComboBox();
            lblPassword = new Label();
            txtPassword = new TextBox();
            btnAdd = new Button();
            btnEdit = new Button();
            btnSave = new Button();
            btnDelete = new Button();
            btnCancel = new Button();
            lblMode = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvUsers).BeginInit();
            gbDetails.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // dgvUsers
            // 
            dgvUsers.AllowUserToAddRows = false;
            dgvUsers.AllowUserToDeleteRows = false;
            dgvUsers.AllowUserToResizeRows = false;
            dgvUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUsers.Location = new Point(20, 20);
            dgvUsers.MultiSelect = false;
            dgvUsers.Name = "dgvUsers";
            dgvUsers.ReadOnly = true;
            dgvUsers.RowHeadersVisible = false;
            dgvUsers.RowHeadersWidth = 51;
            dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUsers.Size = new Size(740, 200);
            dgvUsers.TabIndex = 0;
            dgvUsers.SelectionChanged += dgvUsers_SelectionChanged;
            // 
            // gbDetails
            // 
            gbDetails.Controls.Add(tableLayoutPanel2);
            gbDetails.Location = new Point(20, 240);
            gbDetails.Name = "gbDetails";
            gbDetails.Size = new Size(740, 240);
            gbDetails.TabIndex = 1;
            gbDetails.TabStop = false;
            gbDetails.Text = "Szczegóły użytkownika";
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 75F));
            tableLayoutPanel2.Controls.Add(lblId, 0, 0);
            tableLayoutPanel2.Controls.Add(txtId, 1, 0);
            tableLayoutPanel2.Controls.Add(lblEmail, 0, 1);
            tableLayoutPanel2.Controls.Add(txtEmail, 1, 1);
            tableLayoutPanel2.Controls.Add(lblFirstName, 0, 2);
            tableLayoutPanel2.Controls.Add(txtFirstName, 1, 2);
            tableLayoutPanel2.Controls.Add(lblLastName, 0, 3);
            tableLayoutPanel2.Controls.Add(txtLastName, 1, 3);
            tableLayoutPanel2.Controls.Add(lblCountry, 0, 4);
            tableLayoutPanel2.Controls.Add(txtCountry, 1, 4);
            tableLayoutPanel2.Controls.Add(lblRole, 0, 5);
            tableLayoutPanel2.Controls.Add(cmbRole, 1, 5);
            tableLayoutPanel2.Controls.Add(lblPassword, 0, 6);
            tableLayoutPanel2.Controls.Add(txtPassword, 1, 6);
            tableLayoutPanel2.Location = new Point(10, 25);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 7;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel2.Size = new Size(720, 210);
            tableLayoutPanel2.TabIndex = 0;
            // 
            // lblId
            // 
            lblId.Dock = DockStyle.Fill;
            lblId.Location = new Point(3, 0);
            lblId.Name = "lblId";
            lblId.Size = new Size(174, 30);
            lblId.TabIndex = 0;
            lblId.Text = "ID:";
            lblId.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtId
            // 
            txtId.Dock = DockStyle.Fill;
            txtId.Location = new Point(183, 3);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(534, 27);
            txtId.TabIndex = 1;
            // 
            // lblEmail
            // 
            lblEmail.Dock = DockStyle.Fill;
            lblEmail.Location = new Point(3, 30);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(174, 30);
            lblEmail.TabIndex = 2;
            lblEmail.Text = "E-mail:";
            lblEmail.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtEmail
            // 
            txtEmail.Dock = DockStyle.Fill;
            txtEmail.Location = new Point(183, 33);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(534, 27);
            txtEmail.TabIndex = 3;
            // 
            // lblFirstName
            // 
            lblFirstName.Dock = DockStyle.Fill;
            lblFirstName.Location = new Point(3, 60);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(174, 30);
            lblFirstName.TabIndex = 4;
            lblFirstName.Text = "Imię:";
            lblFirstName.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtFirstName
            // 
            txtFirstName.Dock = DockStyle.Fill;
            txtFirstName.Location = new Point(183, 63);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(534, 27);
            txtFirstName.TabIndex = 5;
            // 
            // lblLastName
            // 
            lblLastName.Dock = DockStyle.Fill;
            lblLastName.Location = new Point(3, 90);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(174, 30);
            lblLastName.TabIndex = 6;
            lblLastName.Text = "Nazwisko:";
            lblLastName.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtLastName
            // 
            txtLastName.Dock = DockStyle.Fill;
            txtLastName.Location = new Point(183, 93);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(534, 27);
            txtLastName.TabIndex = 7;
            // 
            // lblCountry
            // 
            lblCountry.Dock = DockStyle.Fill;
            lblCountry.Location = new Point(3, 120);
            lblCountry.Name = "lblCountry";
            lblCountry.Size = new Size(174, 30);
            lblCountry.TabIndex = 8;
            lblCountry.Text = "Kraj:";
            lblCountry.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtCountry
            // 
            txtCountry.Dock = DockStyle.Fill;
            txtCountry.Location = new Point(183, 123);
            txtCountry.Name = "txtCountry";
            txtCountry.Size = new Size(534, 27);
            txtCountry.TabIndex = 9;
            // 
            // lblRole
            // 
            lblRole.Dock = DockStyle.Fill;
            lblRole.Location = new Point(3, 150);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(174, 30);
            lblRole.TabIndex = 10;
            lblRole.Text = "Rola:";
            lblRole.TextAlign = ContentAlignment.MiddleRight;
            // 
            // cmbRole
            // 
            cmbRole.Dock = DockStyle.Fill;
            cmbRole.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRole.Location = new Point(183, 153);
            cmbRole.Name = "cmbRole";
            cmbRole.Size = new Size(534, 28);
            cmbRole.TabIndex = 11;
            // 
            // lblPassword
            // 
            lblPassword.Dock = DockStyle.Fill;
            lblPassword.Location = new Point(3, 180);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(174, 30);
            lblPassword.TabIndex = 12;
            lblPassword.Text = "Hasło:";
            lblPassword.TextAlign = ContentAlignment.MiddleRight;
            lblPassword.Visible = false;
            // 
            // txtPassword
            // 
            txtPassword.Dock = DockStyle.Fill;
            txtPassword.Location = new Point(183, 183);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(534, 27);
            txtPassword.TabIndex = 13;
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.Visible = false;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(20, 500);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(100, 30);
            btnAdd.TabIndex = 2;
            btnAdd.Text = "Dodaj";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(140, 500);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(100, 30);
            btnEdit.TabIndex = 3;
            btnEdit.Text = "Edytuj";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(260, 500);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(100, 30);
            btnSave.TabIndex = 4;
            btnSave.Text = "Zapisz";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(380, 500);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(100, 30);
            btnDelete.TabIndex = 5;
            btnDelete.Text = "Usuń";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(500, 500);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(100, 30);
            btnCancel.TabIndex = 6;
            btnCancel.Text = "Anuluj";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // lblMode
            // 
            lblMode.AutoSize = true;
            lblMode.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblMode.ForeColor = Color.DarkBlue;
            lblMode.Location = new Point(620, 505);
            lblMode.Name = "lblMode";
            lblMode.Size = new Size(0, 20);
            lblMode.TabIndex = 7;
            // 
            // UserForm
            // 
            ClientSize = new Size(780, 550);
            Controls.Add(dgvUsers);
            Controls.Add(gbDetails);
            Controls.Add(btnAdd);
            Controls.Add(btnEdit);
            Controls.Add(btnSave);
            Controls.Add(btnDelete);
            Controls.Add(btnCancel);
            Controls.Add(lblMode);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "UserForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Zarządzanie użytkownikami";
            Load += UserForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvUsers).EndInit();
            gbDetails.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
    }
}
