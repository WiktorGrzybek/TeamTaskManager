﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeamTaskManager.Models;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Forms
{
    public partial class RegisterForm : Form
    {
        private readonly IUserService _userService;
        public UserSession RegisteredUserSession { get; private set; }

        public RegisterForm(IUserService userService)
        {
            InitializeComponent();
            _userService = userService;
            // Ustawiamy, że przycisk Enter uruchomi rejestrację
            this.AcceptButton = btnRegister;
            // Ustawiamy, że przycisk Esc zamknie formularz (DialogResult.Cancel)
            this.CancelButton = btnCancel;
        }

        private async void btnRegister_Click(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;

            // 1) Walidacja podstawowa
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                lblError.Text = "E-mail jest wymagany.";
                txtEmail.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                lblError.Text = "Hasło jest wymagane.";
                txtPassword.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                lblError.Text = "Imię jest wymagane.";
                txtFirstName.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                lblError.Text = "Nazwisko jest wymagane.";
                txtLastName.Focus();
                return;
            }
            // (opcjonalnie można dodać dalszą walidację np. format e-mail itp.)

            var newUser = new User
            {
                Email = txtEmail.Text.Trim(),
                FirstName = txtFirstName.Text.Trim(),
                LastName = txtLastName.Text.Trim(),
                Country = txtCountry.Text.Trim(),
                Role = UserRole.Member
            };
            string rawPassword = txtPassword.Text;

            try
            {
                // Tworzymy użytkownika
                await _userService.CreateUserAsync(newUser, rawPassword);

                // Po poprawnej rejestracji tworzymy sesję, ustawiamy DialogResult i zamykamy Formę
                RegisteredUserSession = new UserSession
                {
                    UserId = newUser.Id,
                    Email = newUser.Email,
                    FullName = $"{newUser.FirstName} {newUser.LastName}",
                    Role = newUser.Role
                };

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                // Wyświetlamy błąd
                lblError.Text = $"Błąd podczas rejestracji: {ex.Message}";
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Jeśli klikniemy Anuluj, zamykamy formularz ze statusem Cancel
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void linkHaveAccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Jeżeli użytkownik kliknie „Mam już konto”, przerywamy rejestrację i przechodzimy do logowania
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}