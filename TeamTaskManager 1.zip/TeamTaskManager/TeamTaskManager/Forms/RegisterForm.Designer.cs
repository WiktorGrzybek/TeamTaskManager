﻿namespace TeamTaskManager.Forms
{
    partial class RegisterForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.LinkLabel linkHaveAccount; // nowy element

        /// <summary>
        /// Wyczyść wszystkie użyte zasoby.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            lblEmail = new Label();
            txtEmail = new TextBox();
            lblPassword = new Label();
            txtPassword = new TextBox();
            lblFirstName = new Label();
            txtFirstName = new TextBox();
            lblLastName = new Label();
            txtLastName = new TextBox();
            lblCountry = new Label();
            txtCountry = new TextBox();
            btnRegister = new Button();
            btnCancel = new Button();
            lblError = new Label();
            linkHaveAccount = new LinkLabel();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65F));
            tableLayoutPanel1.Controls.Add(lblEmail, 0, 0);
            tableLayoutPanel1.Controls.Add(txtEmail, 1, 0);
            tableLayoutPanel1.Controls.Add(lblPassword, 0, 1);
            tableLayoutPanel1.Controls.Add(txtPassword, 1, 1);
            tableLayoutPanel1.Controls.Add(lblFirstName, 0, 2);
            tableLayoutPanel1.Controls.Add(txtFirstName, 1, 2);
            tableLayoutPanel1.Controls.Add(lblLastName, 0, 3);
            tableLayoutPanel1.Controls.Add(txtLastName, 1, 3);
            tableLayoutPanel1.Controls.Add(lblCountry, 0, 4);
            tableLayoutPanel1.Controls.Add(txtCountry, 1, 4);
            tableLayoutPanel1.Controls.Add(btnRegister, 1, 5);
            tableLayoutPanel1.Controls.Add(btnCancel, 1, 6);
            tableLayoutPanel1.Controls.Add(lblError, 0, 7);
            tableLayoutPanel1.Controls.Add(linkHaveAccount, 1, 8);
            tableLayoutPanel1.Location = new Point(20, 20);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 9;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(380, 300);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // lblEmail
            // 
            lblEmail.Dock = DockStyle.Fill;
            lblEmail.Font = new Font("Segoe UI", 9F);
            lblEmail.Location = new Point(3, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(127, 30);
            lblEmail.TabIndex = 0;
            lblEmail.Text = "E-mail:";
            lblEmail.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtEmail
            // 
            txtEmail.Dock = DockStyle.Fill;
            txtEmail.Location = new Point(136, 3);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(241, 27);
            txtEmail.TabIndex = 1;
            // 
            // lblPassword
            // 
            lblPassword.Dock = DockStyle.Fill;
            lblPassword.Font = new Font("Segoe UI", 9F);
            lblPassword.Location = new Point(3, 30);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(127, 30);
            lblPassword.TabIndex = 2;
            lblPassword.Text = "Hasło:";
            lblPassword.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtPassword
            // 
            txtPassword.Dock = DockStyle.Fill;
            txtPassword.Location = new Point(136, 33);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(241, 27);
            txtPassword.TabIndex = 3;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // lblFirstName
            // 
            lblFirstName.Dock = DockStyle.Fill;
            lblFirstName.Font = new Font("Segoe UI", 9F);
            lblFirstName.Location = new Point(3, 60);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(127, 30);
            lblFirstName.TabIndex = 4;
            lblFirstName.Text = "Imię:";
            lblFirstName.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtFirstName
            // 
            txtFirstName.Dock = DockStyle.Fill;
            txtFirstName.Location = new Point(136, 63);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(241, 27);
            txtFirstName.TabIndex = 5;
            // 
            // lblLastName
            // 
            lblLastName.Dock = DockStyle.Fill;
            lblLastName.Font = new Font("Segoe UI", 9F);
            lblLastName.Location = new Point(3, 90);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(127, 30);
            lblLastName.TabIndex = 6;
            lblLastName.Text = "Nazwisko:";
            lblLastName.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtLastName
            // 
            txtLastName.Dock = DockStyle.Fill;
            txtLastName.Location = new Point(136, 93);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(241, 27);
            txtLastName.TabIndex = 7;
            // 
            // lblCountry
            // 
            lblCountry.Dock = DockStyle.Fill;
            lblCountry.Font = new Font("Segoe UI", 9F);
            lblCountry.Location = new Point(3, 120);
            lblCountry.Name = "lblCountry";
            lblCountry.Size = new Size(127, 30);
            lblCountry.TabIndex = 8;
            lblCountry.Text = "Kraj:";
            lblCountry.TextAlign = ContentAlignment.MiddleRight;
            // 
            // txtCountry
            // 
            txtCountry.Dock = DockStyle.Fill;
            txtCountry.Location = new Point(136, 123);
            txtCountry.Name = "txtCountry";
            txtCountry.Size = new Size(241, 27);
            txtCountry.TabIndex = 9;
            // 
            // btnRegister
            // 
            btnRegister.Dock = DockStyle.Right;
            btnRegister.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnRegister.Location = new Point(257, 153);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(120, 34);
            btnRegister.TabIndex = 10;
            btnRegister.Text = "Zarejestruj";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnCancel
            // 
            btnCancel.Dock = DockStyle.Right;
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.Location = new Point(257, 193);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(120, 34);
            btnCancel.TabIndex = 11;
            btnCancel.Text = "Anuluj";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // lblError
            // 
            tableLayoutPanel1.SetColumnSpan(lblError, 2);
            lblError.Dock = DockStyle.Fill;
            lblError.Font = new Font("Segoe UI", 8F);
            lblError.ForeColor = Color.DarkRed;
            lblError.Location = new Point(3, 230);
            lblError.Name = "lblError";
            lblError.Size = new Size(374, 30);
            lblError.TabIndex = 12;
            lblError.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // linkHaveAccount
            // 
            linkHaveAccount.AutoSize = true;
            linkHaveAccount.Dock = DockStyle.Fill;
            linkHaveAccount.Font = new Font("Segoe UI", 9F, FontStyle.Underline);
            linkHaveAccount.Location = new Point(136, 260);
            linkHaveAccount.Name = "linkHaveAccount";
            linkHaveAccount.Size = new Size(241, 40);
            linkHaveAccount.TabIndex = 13;
            linkHaveAccount.TabStop = true;
            linkHaveAccount.Text = "Mam już konto";
            linkHaveAccount.TextAlign = ContentAlignment.MiddleLeft;
            linkHaveAccount.LinkClicked += linkHaveAccount_LinkClicked;
            // 
            // RegisterForm
            // 
            ClientSize = new Size(420, 340);
            Controls.Add(tableLayoutPanel1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "RegisterForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Rejestracja - TeamTaskManager";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
    }
}
