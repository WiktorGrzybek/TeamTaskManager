﻿// MainForm.Designer.cs
namespace TeamTaskManager.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Button btnManageUsers;
        private System.Windows.Forms.Button btnManageTeams;
        private System.Windows.Forms.Button btnManageTasks;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ToolTip toolTip; // Dodany komponent ToolTip

        /// <summary>
        /// Wyczyść wszystkie użyte zasoby.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);

            this.panelTop = new System.Windows.Forms.Panel();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.picLogo = new System.Windows.Forms.PictureBox();

            this.panelLeft = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnManageTasks = new System.Windows.Forms.Button();
            this.btnManageTeams = new System.Windows.Forms.Button();
            this.btnManageUsers = new System.Windows.Forms.Button();

            // 
            // panelTop
            // 
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Height = 60;
            this.panelTop.BackColor = System.Drawing.Color.SteelBlue;
            this.panelTop.Controls.Add(this.lblWelcome);
            this.panelTop.Controls.Add(this.picLogo);
            this.panelTop.Name = "panelTop";
            // 
            // picLogo
            // 
            // Tu można podstawić dowolny obrazek z zasobów projektu:
            this.picLogo.Size = new System.Drawing.Size(40, 40);
            this.picLogo.Location = new System.Drawing.Point(10, 10);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.Name = "picLogo";
            // 
            // lblWelcome
            // 
            this.lblWelcome.Text = "Witaj, [User]";
            this.lblWelcome.ForeColor = System.Drawing.Color.White;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 12F,
                System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWelcome.Location = new System.Drawing.Point(60, 15);
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Name = "lblWelcome";
            // 
            // panelLeft
            // 
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Width = 180;
            this.panelLeft.BackColor = System.Drawing.Color.LightGray;
            this.panelLeft.Controls.Add(this.btnExit);
            this.panelLeft.Controls.Add(this.btnManageTasks);
            this.panelLeft.Controls.Add(this.btnManageTeams);
            this.panelLeft.Controls.Add(this.btnManageUsers);
            this.panelLeft.Name = "panelLeft";
            // 
            // btnManageUsers
            // 
            this.btnManageUsers.Text = "Użytkownicy";
            this.btnManageUsers.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnManageUsers.Height = 50;
            this.btnManageUsers.Font = new System.Drawing.Font("Segoe UI", 10F,
                System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnManageUsers.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnManageUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageUsers.Name = "btnManageUsers";
            this.btnManageUsers.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnManageUsers.Click += new System.EventHandler(this.btnManageUsers_Click);
            // 
            // btnManageTeams
            // 
            this.btnManageTeams.Text = "Zespoły";
            this.btnManageTeams.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnManageTeams.Height = 50;
            this.btnManageTeams.Font = new System.Drawing.Font("Segoe UI", 10F,
                System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnManageTeams.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnManageTeams.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageTeams.Name = "btnManageTeams";
            this.btnManageTeams.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnManageTeams.Click += new System.EventHandler(this.btnManageTeams_Click);
            // 
            // btnManageTasks
            // 
            this.btnManageTasks.Text = "Zadania";
            this.btnManageTasks.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnManageTasks.Height = 50;
            this.btnManageTasks.Font = new System.Drawing.Font("Segoe UI", 10F,
                System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnManageTasks.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnManageTasks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageTasks.Name = "btnManageTasks";
            this.btnManageTasks.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnManageTasks.Click += new System.EventHandler(this.btnManageTasks_Click);
            // 
            // btnExit
            // 
            this.btnExit.Text = "Wyjście";
            this.btnExit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnExit.Height = 50;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 10F,
                System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnExit.BackColor = System.Drawing.Color.LightCoral;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Name = "btnExit";
            this.btnExit.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelLeft);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "TeamTaskManager – Panel główny";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
        }

        #endregion
    }
}
