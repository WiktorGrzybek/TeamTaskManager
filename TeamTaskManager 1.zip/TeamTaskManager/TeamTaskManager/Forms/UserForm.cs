﻿// File: Forms/UserForm.cs

using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeamTaskManager.Models;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Forms
{
    public partial class UserForm : Form
    {
        private readonly IUserService _userService;
        private readonly UserSession _currentUser;
        private bool _isAddingNew = false;
        private bool _isEditing = false;

        public UserForm(IUserService userService, UserSession currentUser)
        {
            InitializeComponent();
            _userService = userService;
            _currentUser = currentUser;

            // Ustawienia wizualne formy
            this.BackColor = Color.White;
            dgvUsers.BackgroundColor = Color.WhiteSmoke;
            gbDetails.BackColor = Color.WhiteSmoke;
        }

        private async void UserForm_Load(object sender, EventArgs e)
        {
            // 1) Wypełnij ComboBox rolami:
            cmbRole.Items.Clear();
            cmbRole.Items.Add(UserRole.Admin.ToString());
            cmbRole.Items.Add(UserRole.Member.ToString());
            cmbRole.SelectedIndex = 1; // Member jako domyślny

            // 2) Jeśli nie-admin, przyciski „Dodaj” i „Usuń” będą wyłączone,
            //    jednak sam formularz otwieramy w trybie View:
            if (_currentUser.Role != UserRole.Admin)
            {
                btnAdd.Enabled = false;
                btnDelete.Enabled = false;
                btnEdit.Enabled = false;
                btnAdd.BackColor = Color.LightGray;
                btnDelete.BackColor = Color.LightGray;
                btnEdit.BackColor = Color.LightGray;
            }

            await LoadUsersAsync();
            SetMode(ViewMode.View);
        }

        private async Task LoadUsersAsync()
        {
            try
            {
                var users = await _userService.GetAllAsync();
                dgvUsers.DataSource = users;

                // Ukryj kolumny, których nie chcemy pokazywać w DataGridView:
                if (dgvUsers.Columns.Contains("PasswordHash"))
                    dgvUsers.Columns["PasswordHash"].Visible = false;
                if (dgvUsers.Columns.Contains("TeamMembers"))
                    dgvUsers.Columns["TeamMembers"].Visible = false;
                if (dgvUsers.Columns.Contains("TaskAssignments"))
                    dgvUsers.Columns["TaskAssignments"].Visible = false;

                // >>> DODANO: Ukrycie kolumn CreatedTeams i CreatedTasks:
                if (dgvUsers.Columns.Contains("CreatedTeams"))
                    dgvUsers.Columns["CreatedTeams"].Visible = false;
                if (dgvUsers.Columns.Contains("CreatedTasks"))
                    dgvUsers.Columns["CreatedTasks"].Visible = false;

                dgvUsers.ForeColor = Color.Black;
                dgvUsers.EnableHeadersVisualStyles = false;
                dgvUsers.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(230, 230, 250);
                dgvUsers.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas ładowania użytkowników: {ex.Message}",
                                "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvUsers_SelectionChanged(object sender, EventArgs e)
        {
            if ((!_isAddingNew && !_isEditing) && dgvUsers.SelectedRows.Count > 0)
            {
                var user = dgvUsers.SelectedRows[0].DataBoundItem as User;
                if (user != null)
                {
                    txtId.Text = user.Id.ToString();
                    txtEmail.Text = user.Email;
                    txtFirstName.Text = user.FirstName;
                    txtLastName.Text = user.LastName;
                    txtCountry.Text = user.Country;
                    cmbRole.SelectedItem = user.Role.ToString();

                    // W trybie podglądu nie pokazujemy pola hasła:
                    txtPassword.Visible = false;
                    lblPassword.Visible = false;

                    lblMode.Text = "Tryb: Podgląd";
                }
            }
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            // Dodatkowa ochrona: tylko Admin może dodawać użytkowników
            if (_currentUser.Role != UserRole.Admin)
            {
                MessageBox.Show("Brak uprawnień. Tylko administrator może dodawać użytkowników.",
                                "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _isAddingNew = true;
            _isEditing = false;
            SetMode(ViewMode.Add);
            ClearFields();
        }

        private async void btnEdit_Click(object sender, EventArgs e)
        {
            // Tylko Admin może w ogóle wejść w tryb edycji
            if (_currentUser.Role != UserRole.Admin)
            {
                MessageBox.Show("Brak uprawnień. Tylko administrator może edytować użytkowników.",
                                "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dgvUsers.SelectedRows.Count == 0)
                return;

            var user = dgvUsers.SelectedRows[0].DataBoundItem as User;
            if (user == null)
                return;

            _isAddingNew = false;
            _isEditing = true;
            SetMode(ViewMode.Edit);

            // Wypełnij pola danymi wybranego użytkownika
            txtId.Text = user.Id.ToString();
            txtEmail.Text = user.Email;
            txtFirstName.Text = user.FirstName;
            txtLastName.Text = user.LastName;
            txtCountry.Text = user.Country;
            cmbRole.SelectedItem = user.Role.ToString();

            // Pole hasła niewidoczne w edycji (zmiana hasła nie jest obsługiwana tutaj)
            txtPassword.Visible = false;
            lblPassword.Visible = false;

            lblMode.Text = "Tryb: Edycja";
        }

        private bool IsValidEmail(string email)
        {
            // Prosta walidacja: sprawdzamy, czy zawiera '@' oraz '.' po '@'
            if (string.IsNullOrWhiteSpace(email))
                return false;

            int atPos = email.IndexOf('@');
            if (atPos < 1 || atPos == email.Length - 1)
                return false;

            int dotPos = email.IndexOf('.', atPos);
            if (dotPos < atPos + 2 || dotPos == email.Length - 1)
                return false;

            return true;
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (_isAddingNew)
            {
                // Dodawanie nowego użytkownika
                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Pole E-mail jest wymagane.", "Uwaga", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtEmail.Focus();
                    return;
                }
                // >>> WALIDACJA E-MAILA
                if (!IsValidEmail(txtEmail.Text.Trim()))
                {
                    MessageBox.Show("Nieprawidłowy format e-maila.", "Uwaga", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtEmail.Focus();
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Pole Hasło jest wymagane.", "Uwaga", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPassword.Focus();
                    return;
                }

                var newUser = new User
                {
                    Email = txtEmail.Text.Trim(),
                    FirstName = txtFirstName.Text.Trim(),
                    LastName = txtLastName.Text.Trim(),
                    Country = txtCountry.Text.Trim(),
                    Role = (cmbRole.SelectedItem != null &&
                            Enum.TryParse<UserRole>(cmbRole.SelectedItem.ToString(), out var r))
                            ? r
                            : UserRole.Member
                };
                string rawPassword = txtPassword.Text;

                try
                {
                    await _userService.CreateUserAsync(newUser, rawPassword);
                    await LoadUsersAsync();
                    SetMode(ViewMode.View);
                    _isAddingNew = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas dodawania użytkownika: {ex.Message}",
                                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (_isEditing)
            {
                // Edycja istniejącego (tylko dla Admina)
                if (_currentUser.Role != UserRole.Admin)
                {
                    MessageBox.Show("Brak uprawnień. Tylko administrator może edytować użytkowników.",
                                    "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(txtId.Text, out int userId))
                    return;

                // Sprawdź, czy adres e-mail jest poprawny:
                if (string.IsNullOrWhiteSpace(txtEmail.Text) || !IsValidEmail(txtEmail.Text.Trim()))
                {
                    MessageBox.Show("Nieprawidłowy format e-maila.", "Uwaga", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtEmail.Focus();
                    return;
                }

                try
                {
                    var existing = await _userService.GetByIdAsync(userId);
                    if (existing != null)
                    {
                        existing.Email = txtEmail.Text.Trim();
                        existing.FirstName = txtFirstName.Text.Trim();
                        existing.LastName = txtLastName.Text.Trim();
                        existing.Country = txtCountry.Text.Trim();

                        if (cmbRole.SelectedItem != null &&
                            Enum.TryParse<UserRole>(cmbRole.SelectedItem.ToString(), out var rr))
                        {
                            existing.Role = rr;
                        }

                        await _userService.UpdateUserAsync(existing);
                        await LoadUsersAsync();
                        SetMode(ViewMode.View);
                        _isEditing = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas aktualizacji: {ex.Message}",
                                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            // W trybie „View” przycisk Save jest wyłączony, więc nie obsługujemy tego tutaj.
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (_currentUser.Role != UserRole.Admin)
            {
                MessageBox.Show("Brak uprawnień. Tylko administrator może usuwać użytkowników.",
                                "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtId.Text, out int userId))
                return;

            var confirm = MessageBox.Show(
                "Na pewno chcesz usunąć użytkownika? Wszystkie powiązane dane zostaną usunięte.",
                "Potwierdzenie",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                try
                {
                    await _userService.DeleteUserAsync(userId);
                    await LoadUsersAsync();
                    ClearFields();
                    SetMode(ViewMode.View);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas usuwania: {ex.Message}",
                                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _isAddingNew = false;
            _isEditing = false;
            SetMode(ViewMode.View);
            ClearFields();
        }

        private void SetMode(ViewMode mode)
        {
            if (mode == ViewMode.View)
            {
                txtId.ReadOnly = true;
                txtEmail.ReadOnly = true;
                txtFirstName.ReadOnly = true;
                txtLastName.ReadOnly = true;
                txtCountry.ReadOnly = true;
                cmbRole.Enabled = false;
                txtPassword.Visible = false;
                lblPassword.Visible = false;

                btnAdd.Enabled = (_currentUser.Role == UserRole.Admin);
                btnSave.Enabled = false;
                btnDelete.Enabled = (_currentUser.Role == UserRole.Admin && dgvUsers.SelectedRows.Count > 0);
                btnEdit.Enabled = (_currentUser.Role == UserRole.Admin && dgvUsers.SelectedRows.Count > 0);
                btnCancel.Enabled = false;
                lblMode.Text = "Tryb: Podgląd";

                btnAdd.BackColor = btnAdd.Enabled ? Color.LightGreen : Color.LightGray;
                btnDelete.BackColor = btnDelete.Enabled ? Color.LightCoral : Color.LightGray;
                btnEdit.BackColor = btnEdit.Enabled ? Color.LightSkyBlue : Color.LightGray;
            }
            else if (mode == ViewMode.Add)
            {
                txtId.ReadOnly = true;
                txtEmail.ReadOnly = false; // email edytujemy tylko przy dodawaniu
                txtFirstName.ReadOnly = false;
                txtLastName.ReadOnly = false;
                txtCountry.ReadOnly = false;
                cmbRole.Enabled = true;
                txtPassword.Visible = true;
                lblPassword.Visible = true;

                btnAdd.Enabled = false;
                btnSave.Enabled = true;
                btnDelete.Enabled = false;
                btnEdit.Enabled = false;
                btnCancel.Enabled = true;
                lblMode.Text = "Tryb: Dodawanie";

                btnSave.BackColor = Color.LightSkyBlue;
                btnCancel.BackColor = Color.LightGray;
            }
            else // ViewMode.Edit
            {
                txtId.ReadOnly = true;
                txtEmail.ReadOnly = false;  // pozwólmy edytować również email
                txtFirstName.ReadOnly = false;
                txtLastName.ReadOnly = false;
                txtCountry.ReadOnly = false;
                cmbRole.Enabled = true;
                txtPassword.Visible = false;
                lblPassword.Visible = false;

                btnAdd.Enabled = false;
                btnSave.Enabled = true;
                btnDelete.Enabled = false;
                btnEdit.Enabled = false;
                btnCancel.Enabled = true;
                lblMode.Text = "Tryb: Edycja";

                btnSave.BackColor = Color.LightSkyBlue;
                btnCancel.BackColor = Color.LightGray;
            }
        }

        private void ClearFields()
        {
            txtId.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtCountry.Text = string.Empty;
            cmbRole.SelectedIndex = 1; // domyślnie Member
            txtPassword.Text = string.Empty;
        }

        private enum ViewMode
        {
            View,
            Add,
            Edit
        }
    }
}
