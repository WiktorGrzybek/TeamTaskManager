﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Forms
{
    public partial class LoginForm : System.Windows.Forms.Form
    {
        private readonly IUserService _userService;

        public UserSession LoggedUser { get; private set; }

        public LoginForm(IUserService userService)
        {
            InitializeComponent();
            _userService = userService;
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogin;
            txtEmail.Focus();
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            await AttemptLoginAsync();
        }

        private async Task AttemptLoginAsync()
        {
            lblError.Text = string.Empty;
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(email))
            {
                lblError.Text = "Podaj e-mail.";
                txtEmail.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                lblError.Text = "Podaj hasło.";
                txtPassword.Focus();
                return;
            }

            var user = await _userService.AuthenticateAsync(email, password);
            if (user == null)
            {
                lblError.Text = "Niepoprawny e-mail lub hasło.";
                return;
            }

            LoggedUser = new UserSession
            {
                UserId = user.Id,
                Email = user.Email,
                FullName = $"{user.FirstName} {user.LastName}",
                Role = user.Role
            };

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private async void linkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Otwieramy formularz rejestracji
            using (var rf = new RegisterForm(_userService))
            {
                var result = rf.ShowDialog();
                if (result == DialogResult.OK && rf.RegisteredUserSession != null)
                {
                    // Bezpośrednie logowanie
                    LoggedUser = rf.RegisteredUserSession;
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
        }
    }

    public class UserSession
    {
        public int UserId { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public Models.UserRole Role { get; set; }
    }
}
