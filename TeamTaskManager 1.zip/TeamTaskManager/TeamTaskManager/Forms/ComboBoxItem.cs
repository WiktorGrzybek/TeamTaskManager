﻿using System;

namespace TeamTaskManager.Forms
{
    /// <summary>
    /// Prosta klasa-wrappper do przechowywania pary (Id, Tekst) w ComboBoxach i CheckedListBoxach.
    /// </summary>
    public class ComboBoxItem
    {
        public int Id { get; set; }
        public string Text { get; set; }

        public ComboBoxItem(int id, string text)
        {
            Id = id;
            Text = text;
        }

        public override string ToString()
        {
            // Gdy wstawi się obiekt tej klasy do ComboBox.Items, ToString() zwróci jego Text.
            return Text;
        }
    }
}
