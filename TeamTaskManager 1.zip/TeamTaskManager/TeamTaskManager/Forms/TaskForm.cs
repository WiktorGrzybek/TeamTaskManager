﻿// File: Forms/TaskForm.cs

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using TeamTaskManager.Models;
using TeamTaskManager.Services.Interfaces;

namespace TeamTaskManager.Forms
{
    public partial class TaskForm : Form
    {
        private readonly ITaskService _taskService;
        private readonly ITeamService _teamService;
        private readonly IUserService _userService;
        private readonly UserSession _currentUser;
        private bool _isAddingNew = false;

        // Lista dopuszczalnych statusów zadania:
        private readonly List<string> _allStatuses = new List<string>
        {
            "Nierozpoczęte",
            "Nowe",
            "W toku",
            "Zakończone"
        };

        public TaskForm(
            ITaskService taskService,
            ITeamService teamService,
            IUserService userService,
            UserSession currentUser)
        {
            InitializeComponent();
            _taskService = taskService;
            _teamService = teamService;
            _userService = userService;
            _currentUser = currentUser;

            // Wygląd
            this.BackColor = Color.White;
            dgvTasks.BackgroundColor = Color.WhiteSmoke;
            gbTaskDetails.BackColor = Color.WhiteSmoke;
            gbProgressHistory.BackColor = Color.WhiteSmoke;

            // Przygotuj ComboBox ze statusami (dla zadania)
            cmbStatus.Items.Clear();
            foreach (var s in _allStatuses)
                cmbStatus.Items.Add(s);
            cmbStatus.SelectedIndex = 0; // domyślnie "Nierozpoczęte"

            // Przygotuj ComboBox ze statusami (dla dodawania postępu)
            cmbProgressStatus.Items.Clear();
            foreach (var s in _allStatuses)
                cmbProgressStatus.Items.Add(s);
            cmbProgressStatus.SelectedIndex = 0; // domyślnie "Nierozpoczęte"
        }

        private async void TaskForm_Load(object sender, EventArgs e)
        {
            await LoadTasksAsync();
            await LoadTeamsAsync();
            await LoadUsersAsync();
            SetMode(ViewMode.View);
        }

        private async Task LoadTasksAsync()
        {
            var tasks = await _taskService.GetAllAsync();
            dgvTasks.DataSource = tasks;

            // Ukryj niepotrzebne kolumny:
            if (dgvTasks.Columns.Contains("Progresses"))
                dgvTasks.Columns["Progresses"].Visible = false;
            if (dgvTasks.Columns.Contains("TaskAssignments"))
                dgvTasks.Columns["TaskAssignments"].Visible = false;
            if (dgvTasks.Columns.Contains("CreatedByUserId"))
                dgvTasks.Columns["CreatedByUserId"].Visible = false;

            // Styl nagłówków:
            dgvTasks.EnableHeadersVisualStyles = false;
            dgvTasks.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(230, 230, 250);
            dgvTasks.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        }

        private async Task LoadTeamsAsync()
        {
            var teams = await _teamService.GetAllAsync();
            cmbTeam.Items.Clear();
            foreach (var t in teams)
            {
                cmbTeam.Items.Add(new TaskComboBoxItem(t.Id, t.Name));
            }
        }

        private async Task LoadUsersAsync()
        {
            var users = await _userService.GetAllAsync();
            clbAssignedUsers.Items.Clear();
            foreach (var u in users)
            {
                clbAssignedUsers.Items.Add(new TaskComboBoxItem(u.Id, $"{u.FirstName} {u.LastName}"));
            }
        }

        private async void dgvTasks_SelectionChanged(object sender, EventArgs e)
        {
            if (!_isAddingNew && dgvTasks.SelectedRows.Count > 0)
            {
                var taskItem = dgvTasks.SelectedRows[0].DataBoundItem as TaskItem;
                if (taskItem != null)
                {
                    txtId.Text = taskItem.Id.ToString();
                    txtTitle.Text = taskItem.Title;
                    txtDescription.Text = taskItem.Description;
                    dtpDueDate.Value = taskItem.DueDate;

                    // Ustawienie ComboBox‐a z zespołami
                    for (int i = 0; i < cmbTeam.Items.Count; i++)
                    {
                        if (((TaskComboBoxItem)cmbTeam.Items[i]).Id == taskItem.TeamId)
                        {
                            cmbTeam.SelectedIndex = i;
                            break;
                        }
                    }

                    // Ustawienie CheckedListBox‐a z przypisanymi użytkownikami
                    for (int i = 0; i < clbAssignedUsers.Items.Count; i++)
                    {
                        var cbi = (TaskComboBoxItem)clbAssignedUsers.Items[i];
                        clbAssignedUsers.SetItemChecked(i,
                            taskItem.TaskAssignments.Any(ta => ta.UserId == cbi.Id));
                    }

                    // Wyświetl historię postępów
                    dgvProgress.DataSource = taskItem.Progresses
                        .OrderBy(p => p.Timestamp)
                        .Select(p => new { p.Status, p.Comment, p.Timestamp })
                        .ToList();

                    // Ustaw ComboBox statusu (zadania) na ostatni zapisany status
                    if (_allStatuses.Contains(taskItem.CurrentStatus))
                        cmbStatus.SelectedItem = taskItem.CurrentStatus;
                    else
                        cmbStatus.SelectedIndex = 0;

                    lblMode.Text = "Tryb: Podgląd";

                    // Resetuj także pole wyboru statusu w sekcji „Historia postępów”:
                    cmbProgressStatus.SelectedIndex = 0;
                    txtProgressComment.Text = string.Empty;
                }
            }
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            _isAddingNew = true;
            SetMode(ViewMode.Add);
            ClearFields();

            // Nowe zadanie domyślnie ma status "Nierozpoczęte"
            cmbStatus.SelectedIndex = 0;
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (_isAddingNew)
            {
                // Dodawanie nowego zadania
                if (!(cmbTeam.SelectedItem is TaskComboBoxItem selectedTeam))
                    return;

                var newTask = new TaskItem
                {
                    Title = txtTitle.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    DueDate = dtpDueDate.Value,
                    CreatedByUserId = _currentUser.UserId,
                    TeamId = selectedTeam.Id,
                    CurrentStatus = cmbStatus.SelectedItem.ToString()
                };

                try
                {
                    await _taskService.CreateTaskAsync(
                        newTask,
                        clbAssignedUsers.CheckedItems
                            .Cast<TaskComboBoxItem>()
                            .Select(c => c.Id)
                            .ToList()
                    );
                    await LoadTasksAsync();
                    SetMode(ViewMode.View);
                    _isAddingNew = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas dodawania zadania: {ex.Message}",
                                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Edycja istniejącego zadania
                if (!int.TryParse(txtId.Text, out int taskId))
                    return;

                var existing = await _taskService.GetByIdAsync(taskId);
                if (existing == null)
                    return;

                // Sprawdzenie uprawnień: Admin lub właściciel zadania
                if (_currentUser.Role != UserRole.Admin
                    && existing.CreatedByUserId != _currentUser.UserId)
                {
                    MessageBox.Show("Brak uprawnień. Tylko właściciel zadania lub administrator może je edytować.",
                                    "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!(cmbTeam.SelectedItem is TaskComboBoxItem selTeam))
                    return;

                try
                {
                    existing.Title = txtTitle.Text.Trim();
                    existing.Description = txtDescription.Text.Trim();
                    existing.DueDate = dtpDueDate.Value;
                    existing.TeamId = selTeam.Id;
                    existing.CurrentStatus = cmbStatus.SelectedItem.ToString();

                    var selectedUserIds = clbAssignedUsers.CheckedItems
                        .Cast<TaskComboBoxItem>()
                        .Select(c => c.Id)
                        .ToList();

                    await _taskService.UpdateTaskAsync(existing, selectedUserIds);
                    await LoadTasksAsync();
                    SetMode(ViewMode.View);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas aktualizacji: {ex.Message}",
                                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out int taskId))
                return;

            var toDelete = await _taskService.GetByIdAsync(taskId);
            if (toDelete == null)
                return;

            // Sprawdzenie uprawnień: Admin lub właściciel zadania
            if (_currentUser.Role != UserRole.Admin
                && toDelete.CreatedByUserId != _currentUser.UserId)
            {
                MessageBox.Show("Brak uprawnień. Możesz usuwać tylko własne zadania.",
                                "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var confirm = MessageBox.Show("Na pewno chcesz usunąć zadanie?",
                                           "Potwierdzenie", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm == DialogResult.Yes)
            {
                try
                {
                    await _taskService.DeleteTaskAsync(taskId);
                    await LoadTasksAsync();
                    ClearFields();
                    SetMode(ViewMode.View);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd podczas usuwania: {ex.Message}",
                                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _isAddingNew = false;
            SetMode(ViewMode.View);
            ClearFields();
        }

        private async void btnAddProgress_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out int taskId))
                return;

            var toUpdate = await _taskService.GetByIdAsync(taskId);
            if (toUpdate == null)
                return;

            // Sprawdzenie uprawnień: Admin lub właściciel zadania
            if (_currentUser.Role != UserRole.Admin
                && toUpdate.CreatedByUserId != _currentUser.UserId)
            {
                MessageBox.Show("Brak uprawnień. Tylko właściciel zadania lub administrator może dodać postęp.",
                                "Brak dostępu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string comment = txtProgressComment.Text.Trim();
            if (string.IsNullOrEmpty(comment))
                return;

            // Pobieramy status z nowego pola cmbProgressStatus:
            string selectedStatus = cmbProgressStatus.SelectedItem.ToString();
            try
            {
                var newProg = new Progress
                {
                    Status = selectedStatus,
                    Comment = comment
                };
                // Dodajemy wpis do historii postępów:
                await _taskService.AddProgressAsync(taskId, newProg);

                // Po dodaniu progress: odświeżamy górną listę zadań i historię:
                await LoadTasksAsync();
                var updated = await _taskService.GetByIdAsync(taskId);

                dgvProgress.DataSource = updated.Progresses
                    .OrderBy(p => p.Timestamp)
                    .Select(p => new { p.Status, p.Comment, p.Timestamp })
                    .ToList();

                // I aktualizujemy górne pole statusu (cmbStatus) do wybranego w nowym wpisie:
                if (_allStatuses.Contains(selectedStatus))
                {
                    cmbStatus.SelectedItem = selectedStatus;
                }

                // Wyczyść pola komentarza i zostaw ustawiony status w cmbProgressStatus:
                txtProgressComment.Text = string.Empty;
                // (opcjonalnie można zresetować na domyślny 0 lub zostawić to, co było
                //  cmbProgressStatus.SelectedIndex = 0;)
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas dodawania postępu: {ex.Message}",
                                "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearFields()
        {
            txtId.Text = string.Empty;
            txtTitle.Text = string.Empty;
            txtDescription.Text = string.Empty;
            dtpDueDate.Value = DateTime.Now;
            cmbTeam.SelectedIndex = -1;
            for (int i = 0; i < clbAssignedUsers.Items.Count; i++)
                clbAssignedUsers.SetItemChecked(i, false);

            dgvProgress.DataSource = null;
            txtProgressComment.Text = string.Empty;
            cmbStatus.SelectedIndex = 0;
            cmbProgressStatus.SelectedIndex = 0;
        }

        private void SetMode(ViewMode mode)
        {
            if (mode == ViewMode.View)
            {
                txtId.ReadOnly = true;
                txtTitle.ReadOnly = true;
                txtDescription.ReadOnly = true;
                dtpDueDate.Enabled = false;
                cmbTeam.Enabled = false;
                clbAssignedUsers.Enabled = false;
                cmbStatus.Enabled = false;
                cmbProgressStatus.Enabled = true;
                txtProgressComment.Enabled = true;
                btnAddProgress.Enabled = true;

                btnAdd.Enabled = true;
                btnSave.Enabled = false;
                btnDelete.Enabled = false;
                btnCancel.Enabled = false;
                lblMode.Text = "Tryb: Podgląd";

                if (dgvTasks.SelectedRows.Count > 0)
                {
                    var sel = dgvTasks.SelectedRows[0].DataBoundItem as TaskItem;
                    if (sel != null &&
                        (_currentUser.Role == UserRole.Admin || sel.CreatedByUserId == _currentUser.UserId))
                    {
                        btnDelete.Enabled = true;
                    }
                }
            }
            else // Tryb Dodawanie / Edycja
            {
                txtId.ReadOnly = true;
                txtTitle.ReadOnly = false;
                txtDescription.ReadOnly = false;
                dtpDueDate.Enabled = true;
                cmbTeam.Enabled = true;
                clbAssignedUsers.Enabled = true;
                cmbStatus.Enabled = true;
                cmbProgressStatus.Enabled = true;    // status progress włączamy tylko przy kliknięciu "Dodaj"
                txtProgressComment.Enabled = true;
                btnAddProgress.Enabled = true;

                btnAdd.Enabled = false;
                btnSave.Enabled = true;
                btnDelete.Enabled = !_isAddingNew;
                btnCancel.Enabled = true;
                lblMode.Text = _isAddingNew ? "Tryb: Dodawanie" : "Tryb: Edycja";
            }
        }

        private enum ViewMode
        {
            View,
            Add,
            Edit
        }
    }

    /// <summary>
    /// Pomocnicza klasa do przechowywania Id i Tekstu w ComboBox/CheckedListBox w TaskForm
    /// </summary>
    public class TaskComboBoxItem
    {
        public int Id { get; set; }
        public string Text { get; set; }

        public TaskComboBoxItem(int id, string text)
        {
            Id = id;
            Text = text;
        }

        public override string ToString()
        {
            return Text;
        }
    }
}
