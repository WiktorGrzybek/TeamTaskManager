﻿// Program.cs
using System;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using TeamTaskManager.Data;
using TeamTaskManager.Forms;
using TeamTaskManager.Services.Implementations;
using TeamTaskManager.Services.Interfaces;
using TeamTaskManager.Models;

namespace TeamTaskManager
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // 1. Konfiguracja HostBuilder-a, DI i EF Core:
            var builder = Host.CreateDefaultBuilder()
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
                })
                .ConfigureServices((context, services) =>
                {
                    var connectionString = context.Configuration.GetConnectionString("DefaultConnection");
                    services.AddDbContext<AppDbContext>(options =>
                        options.UseNpgsql(
                            connectionString,
                            sql => sql.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery))
                    );

                    services.AddScoped<IUserService, UserService>();
                    services.AddScoped<ITeamService, TeamService>();
                    services.AddScoped<ITaskService, TaskService>();

                    // Rejestracja formularzy w DI:
                    services.AddScoped<LoginForm>();
                    services.AddScoped<RegisterForm>();

                    // MainForm rejestrowane fabrycznie, aby móc przekazać bieżącą sesję:
                    services.AddScoped<Func<UserSession, MainForm>>(provider => (session) =>
                        new MainForm(
                            provider.GetRequiredService<IUserService>(),
                            provider.GetRequiredService<ITeamService>(),
                            provider.GetRequiredService<ITaskService>(),
                            session      // przekazywana bieżąca sesja
                        )
                    );
                });

            var host = builder.Build();

            // 2. Zastosowanie migracji i zasianie danych:
            using (var scope = host.Services.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                context.Database.Migrate();
                SeedData.Initialize(context);
            }

            // 3. Uruchomienie WinForms:
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 4. Wyświetlenie RegisterForm → jeśli użytkownik kliknie „Zarejestruj” lub „Zaloguj”,
            //    w zależności od wyboru przechodzimy dalej.
            using (var scope = host.Services.CreateScope())
            {
                var registerForm = scope.ServiceProvider.GetRequiredService<RegisterForm>();
                var dialog = registerForm.ShowDialog();

                if (dialog == DialogResult.OK)
                {
                    // Po udanej rejestracji lub gdy chce się zalogować bezpośrednio,
                    // otwieramy LoginForm.
                    var loginForm = scope.ServiceProvider.GetRequiredService<LoginForm>();
                    if (loginForm.ShowDialog() == DialogResult.OK)
                    {
                        // Mamy zalogowanego użytkownika – tworzymy MainForm z przekazaną sesją:
                        var createMain = scope.ServiceProvider.GetRequiredService<Func<UserSession, MainForm>>();
                        var mainForm = createMain(loginForm.LoggedUser);
                        Application.Run(mainForm);
                    }
                }
                else
                {
                    // Jeśli registerForm zwróciło Anuluj, zamykamy aplikację.
                    Application.Exit();
                }
            }
        }
    }
}
