﻿using Microsoft.EntityFrameworkCore;
using TeamTaskManager.Models;

namespace TeamTaskManager.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<TeamMember> TeamMembers { get; set; }
        public DbSet<TaskItem> TaskItems { get; set; }
        public DbSet<TaskAssignment> TaskAssignments { get; set; }
        public DbSet<Progress> Progresses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // =========================
            // 1. Konfiguracja User
            // =========================
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasIndex(u => u.Email).IsUnique();

                entity.Property(u => u.Email)
                      .IsRequired()
                      .HasMaxLength(150);

                entity.Property(u => u.PasswordHash)
                      .IsRequired();

                entity.Property(u => u.FirstName)
                      .IsRequired()
                      .HasMaxLength(50);

                entity.Property(u => u.LastName)
                      .IsRequired()
                      .HasMaxLength(50);

                entity.Property(u => u.Country)
                      .HasMaxLength(50);

                // Relacje 1:N z TeamMembers
                entity.HasMany(u => u.TeamMembers)
                      .WithOne(tm => tm.User)
                      .HasForeignKey(tm => tm.UserId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Relacje 1:N z TaskAssignments
                entity.HasMany(u => u.TaskAssignments)
                      .WithOne(ta => ta.User)
                      .HasForeignKey(ta => ta.UserId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Relacja 1:N dla utworzonych Teams i Tasks
                entity.HasMany(u => u.CreatedTeams)
                      .WithOne(t => t.CreatedByUser)
                      .HasForeignKey(t => t.CreatedByUserId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasMany(u => u.CreatedTasks)
                      .WithOne(t => t.CreatedByUser)
                      .HasForeignKey(t => t.CreatedByUserId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // =========================
            // 2. Konfiguracja Team
            // =========================
            modelBuilder.Entity<Team>(entity =>
            {
                entity.HasIndex(t => t.Name).IsUnique();

                entity.Property(t => t.Name)
                      .IsRequired()
                      .HasMaxLength(100);

                entity.Property(t => t.Description)
                      .HasMaxLength(500);

                // Relacja do użytkownika, który utworzył zespół
                entity.Property(t => t.CreatedByUserId).IsRequired();

                entity.HasOne(t => t.CreatedByUser)
                      .WithMany(u => u.CreatedTeams)
                      .HasForeignKey(t => t.CreatedByUserId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Nawigacja TeamMembers
                entity.HasMany(t => t.TeamMembers)
                      .WithOne(tm => tm.Team)
                      .HasForeignKey(tm => tm.TeamId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Nawigacja do zadań w zespole
                entity.HasMany(t => t.TaskItems)
                      .WithOne(ti => ti.Team)
                      .HasForeignKey(ti => ti.TeamId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // =========================
            // 3. Konfiguracja TeamMember (N:M User–Team)
            // =========================
            modelBuilder.Entity<TeamMember>(entity =>
            {
                entity.HasKey(tm => new { tm.UserId, tm.TeamId });

                entity.HasOne(tm => tm.User)
                      .WithMany(u => u.TeamMembers)
                      .HasForeignKey(tm => tm.UserId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(tm => tm.Team)
                      .WithMany(t => t.TeamMembers)
                      .HasForeignKey(tm => tm.TeamId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // =========================
            // 4. Konfiguracja TaskItem
            // =========================
            modelBuilder.Entity<TaskItem>(entity =>
            {
                entity.HasKey(t => t.Id);

                entity.Property(t => t.Title)
                      .IsRequired()
                      .HasMaxLength(200);

                entity.Property(t => t.Description)
                      .HasMaxLength(1000);

                entity.Property(t => t.CreatedAt)
                      .HasDefaultValueSql("NOW()")
                      .ValueGeneratedOnAdd();

                entity.Property(t => t.DueDate).IsRequired();

                entity.Property(t => t.CurrentStatus)
                      .HasMaxLength(50);

                // Relacja 1 Team → N TaskItem
                entity.HasOne(t => t.Team)
                      .WithMany(team => team.TaskItems)
                      .HasForeignKey(t => t.TeamId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Relacja do użytkownika, który utworzył zadanie
                entity.Property(t => t.CreatedByUserId).IsRequired();

                entity.HasOne(t => t.CreatedByUser)
                      .WithMany(u => u.CreatedTasks)
                      .HasForeignKey(t => t.CreatedByUserId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Nawigacja TaskAssignments
                entity.HasMany(t => t.TaskAssignments)
                      .WithOne(ta => ta.TaskItem)
                      .HasForeignKey(ta => ta.TaskItemId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Nawigacja Progresses
                entity.HasMany(t => t.Progresses)
                      .WithOne(p => p.TaskItem)
                      .HasForeignKey(p => p.TaskItemId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // =========================
            // 5. Konfiguracja TaskAssignment (N:M User–TaskItem)
            // =========================
            modelBuilder.Entity<TaskAssignment>(entity =>
            {
                entity.HasKey(ta => new { ta.TaskItemId, ta.UserId });

                entity.HasOne(ta => ta.TaskItem)
                      .WithMany(t => t.TaskAssignments)
                      .HasForeignKey(ta => ta.TaskItemId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(ta => ta.User)
                      .WithMany(u => u.TaskAssignments)
                      .HasForeignKey(ta => ta.UserId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // =========================
            // 6. Konfiguracja Progress
            // =========================
            modelBuilder.Entity<Progress>(entity =>
            {
                entity.HasKey(p => p.Id);

                entity.Property(p => p.Status)
                      .IsRequired()
                      .HasMaxLength(50);

                entity.Property(p => p.Comment)
                      .HasMaxLength(500);

                entity.Property(p => p.Timestamp)
                      .HasDefaultValueSql("NOW()")
                      .ValueGeneratedOnAdd();

                entity.HasOne(p => p.TaskItem)
                      .WithMany(t => t.Progresses)
                      .HasForeignKey(p => p.TaskItemId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}
