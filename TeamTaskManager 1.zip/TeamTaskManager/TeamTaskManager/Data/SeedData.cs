﻿using System;
using System.Collections.Generic;
using System.Linq;
using TeamTaskManager.Models;

namespace TeamTaskManager.Data
{
    public static class SeedData
    {
        public static void Initialize(AppDbContext context)
        {
            // 1. Sprawdź, czy baza jest pusta. Jeśli nie, pomiń seedowanie.
            if (context.Users.Any() || context.Teams.Any() || context.TaskItems.Any())
            {
                return;
            }

            // 2. Dodajemy przykładowych użytkowników:
            var users = new List<User>
            {
                new User
                {
                    Email = "admin@firma.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin123!"),
                    FirstName = "Jan",
                    LastName = "Kowalski",
                    Country = "Polska",
                    Role = UserRole.Admin
                },
                new User
                {
                    Email = "user1@firma.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("User123!"),
                    FirstName = "Anna",
                    LastName = "Nowak",
                    Country = "Niemcy",
                    Role = UserRole.Member
                },
                new User
                {
                    Email = "user2@firma.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("User456!"),
                    FirstName = "Piotr",
                    LastName = "Wiśniewski",
                    Country = "Polska",
                    Role = UserRole.Member
                }
            };
            context.Users.AddRange(users);
            context.SaveChanges();

            // 3. Dodajemy zespoły (ustawiamy CreatedByUserId = admin)
            var adminId = users.Single(u => u.Email == "admin@firma.com").Id;
            var teams = new List<Team>
            {
                new Team { Name = "Projekt A", Description = "Zespół do rozwoju projektu A", CreatedByUserId = adminId },
                new Team { Name = "Projekt B", Description = "Zespół do badań nad projektem B", CreatedByUserId = adminId }
            };
            context.Teams.AddRange(teams);
            context.SaveChanges();

            // 4. Łączymy użytkowników z zespołami (TeamMembers):
            var teamMembers = new List<TeamMember>
            {
                new TeamMember { UserId = users.Single(u => u.Email == "admin@firma.com").Id, TeamId = teams[0].Id },
                new TeamMember { UserId = users.Single(u => u.Email == "user1@firma.com").Id, TeamId = teams[0].Id },
                new TeamMember { UserId = users.Single(u => u.Email == "user2@firma.com").Id, TeamId = teams[1].Id }
            };
            context.TeamMembers.AddRange(teamMembers);
            context.SaveChanges();

            // 5. Tworzymy przykładowe zadania (CreatedByUserId = admin):
            var now = DateTime.UtcNow;
            var taskItems = new List<TaskItem>
            {
                new TaskItem
                {
                    Title = "Założenie repozytorium",
                    Description = "Stworzyć repozytorium Git i skonfigurować uprawnienia",
                    DueDate = now.AddDays(7),
                    TeamId = teams[0].Id,
                    CreatedByUserId = adminId,
                    CurrentStatus = "W toku"
                },
                new TaskItem
                {
                    Title = "Analiza wymagań",
                    Description = "Zebrać wymagania od interesariuszy dla Projektu A",
                    DueDate = now.AddDays(14),
                    TeamId = teams[0].Id,
                    CreatedByUserId = adminId,
                    CurrentStatus = "W toku"
                },
                new TaskItem
                {
                    Title = "Prototyp interfejsu",
                    Description = "Przygotować wstępny prototyp interfejsu WinForms",
                    DueDate = now.AddDays(10),
                    TeamId = teams[1].Id,
                    CreatedByUserId = adminId,
                    CurrentStatus = "W toku"
                }
            };
            context.TaskItems.AddRange(taskItems);
            context.SaveChanges();

            // 6. Przydzielenie zadań użytkownikom (TaskAssignments):
            var taskAssignments = new List<TaskAssignment>
            {
                new TaskAssignment
                {
                    TaskItemId = taskItems.Single(t => t.Title == "Założenie repozytorium").Id,
                    UserId = users.Single(u => u.Email == "user1@firma.com").Id
                },
                new TaskAssignment
                {
                    TaskItemId = taskItems.Single(t => t.Title == "Analiza wymagań").Id,
                    UserId = users.Single(u => u.Email == "admin@firma.com").Id
                },
                new TaskAssignment
                {
                    TaskItemId = taskItems.Single(t => t.Title == "Prototyp interfejsu").Id,
                    UserId = users.Single(u => u.Email == "user2@firma.com").Id
                }
            };
            context.TaskAssignments.AddRange(taskAssignments);
            context.SaveChanges();

            // 7. Dodanie przykładowych wpisów Progress:
            var progressList = new List<Progress>
            {
                new Progress
                {
                    TaskItemId = taskItems.Single(t => t.Title == "Założenie repozytorium").Id,
                    Status = "W toku",
                    Comment = "Zainicjowano repozytorium na GitHub",
                    Timestamp = now
                },
                new Progress
                {
                    TaskItemId = taskItems.Single(t => t.Title == "Analiza wymagań").Id,
                    Status = "Nowe",
                    Comment = "Czekamy na spotkanie z interesariuszami",
                    Timestamp = now
                }
            };
            context.Progresses.AddRange(progressList);
            context.SaveChanges();
        }
    }
}
